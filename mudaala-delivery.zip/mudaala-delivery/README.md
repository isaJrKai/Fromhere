# Mudaala Delivery

Backend for Mudaala's in-app boda deliveries. A seller requests a delivery, nearby approved
riders are offered the job, the first to accept wins, the buyer's secret code confirms the
handover, and both sides can then review the rider.

Python 3.13, Flask, SQLite (WAL). API only: there is no mobile app and no admin web panel.

## Read this first: what is and is not production-ready

**Built and tested** (69 automated tests, including real multi-threaded race tests):
accounts and tokens, rider vetting and a trust ladder, nearest-rider matching with offer
timeouts, safe job assignment, PIN-confirmed delivery with brute-force lockout, reviews with
system-measured timing, a payments model with signed webhooks, an SMS outbox, audit trail,
rate limiting, structured logs, health check, Docker files.

**Not done. You must do these before real customers use it:**

| Gap | Why it matters |
|---|---|
| Real mobile money integration | `payments.py` defines the contract but ships no MTN MoMo / Airtel Money adapter. You need merchant accounts and must test against their sandbox. Until then, mobile money charges fail and retry. Only cash works. |
| Real SMS gateway | Messages are only logged. Plug in a provider (for example Africa's Talking) by passing an object with `send(phone, body)`. Buyers never get their delivery code until this is done. |
| Phone number verification | Registration does not send an OTP, so anyone can sign up with a number they do not own. There is also no password reset. |
| Push notifications | Riders find offers by polling `GET /v1/bodas/me/offers` every 5 to 10 seconds. Offers last 60 seconds, so push (FCM) is needed for a good experience. |
| Personal data protection | National ID numbers and guarantor details are stored unencrypted. Add encryption at rest, restrict who can read them, and take advice on Uganda's Data Protection and Privacy Act and registration. |
| Cash commission | For cash jobs the rider keeps the cash, so the commission is recorded but nothing collects it. You need a settlement process (for example, deduct from future mobile money earnings or require top-ups). |
| Hosting hardening | Put TLS in front (Caddy or nginx), set `MUDAALA_TRUST_PROXY_HOPS=1`, run backups (`sqlite3 mudaala.db ".backup file"`), and set up monitoring and log shipping. |
| Rate limiting at scale | Limits live in each process's memory, so the real limit is multiplied by the number of workers. Use a shared store when you run more than one server. |
| Moving off SQLite | Fine for one server and one area. Move to PostgreSQL (with PostGIS for location search) before you need several servers or heavy traffic. |
| Not load-tested or pen-tested | Get an independent security review before launch. |
| Privacy of phone numbers | Seller and rider see each other's numbers directly. Masked calling would stop them dealing off-app. |
| Disputes, refunds, insurance | Only a basic admin "resolve" action exists. Lost or damaged goods need a policy, and probably insurance. |
| Docker files untested | Written but not built here (no Docker daemon available in the build environment). Test `docker compose up` yourself. `gunicorn` was also not run here; the dev server was. |

## Quick start (development)

```bash
pip install -r requirements-dev.txt
python -m pytest                              # run the tests
python -m mudaala_delivery migrate            # create the database
MUDAALA_ADMIN_PASSWORD='a-long-password' python -m mudaala_delivery create-admin --phone 0700123456 --name "Your Name"
python -m mudaala_delivery serve              # API on http://localhost:8000
python -m mudaala_delivery worker             # in a second terminal
```

In development, secrets are generated fresh on every start, so restarting the server signs
everyone out. In production the three secrets must be set (see `.env.example`) or the app
refuses to start.

## How it works

```
seller creates delivery ──► SEARCHING ──► offers to nearest 3 riders (60 s)
                               │                 │ first accept wins
                               │                 ▼
                               │             ASSIGNED ──► PICKED_UP ──► DELIVERED
                               │                 │            (buyer's 4-digit code)
                               ▼                 ▼
                       NO_BODA after 3     rider drops it: back to SEARCHING
                       empty rounds         seller cancels: CANCELLED
```

- **Matching.** Riders must be approved, available, have a location ping under 2 minutes old,
  be within 5 km of the pickup, have no job in progress, and be trusted to carry the item's
  value. New riders carry up to UGX 200,000; the limit rises by 100,000 every 10 successful
  deliveries (capped at 1,000,000). All tunable.
- **Safe assignment.** Every change runs in one write transaction, so two riders accepting
  the same job at once get one winner and one clean `409`. The tests force this overlap.
- **Handover code.** The buyer is texted a 4-digit code when the delivery is created. The
  seller never sees it, and it is stored only as a keyed hash. The rider enters it to finish.
  Five wrong tries lock the delivery; an admin resolves it.
- **Reviews.** Only confirmed deliveries, once per reviewer (seller and buyer). Timing is
  measured from pickup to code confirmation against the ETA, and cannot be typed in. "Goods"
  means condition on arrival (with a note if damaged). Courtesy is 1 to 5. A rider's score is
  hidden until 3 reviews and is pulled toward a neutral 4.0 so one review cannot make or break
  them. Buyers have no account; they review through a secret link texted after delivery.
- **Pricing.** `fee = base 2,000 + 800 per km`, rounded up to the next 500, with road distance
  estimated as straight-line distance x 1.4. Commission is 10%. No surge pricing.
- **Money.** Cash is recorded as paid on confirmation. Mobile money is charged through your
  provider adapter, treating the payment id as an idempotency key, and settled by a signed
  webhook. Failed charges retry up to 5 times and never block the delivery.
- **Worker.** One worker process moves jobs to the next round when offers expire, sends SMS
  from an outbox (so a crash cannot lose or duplicate a message), and retries payments.

## API

All paths are under `/v1`. Send `Authorization: Bearer <access_token>`. Errors look like
`{"error": {"code": "...", "message": "..."}}`.

| Who | Endpoint |
|---|---|
| Anyone | `POST /auth/register` `POST /auth/login` `POST /auth/refresh` `POST /auth/logout` |
| Seller | `POST /quote` `POST /deliveries` (send an `Idempotency-Key` header) `GET /deliveries` `GET /deliveries/{id}` `POST /deliveries/{id}/cancel` `POST /deliveries/{id}/review` |
| Rider | `POST /bodas/me/profile` `GET /bodas/me` `PUT /bodas/me/availability` `POST /bodas/me/location` `GET /bodas/me/offers` `GET /bodas/me/active` `GET /bodas/me/history` `GET /bodas/me/earnings` `POST /deliveries/{id}/accept` `.../decline` `.../pickup` `.../confirm` `.../cancel` `POST /reviews/{id}/reply` |
| Any signed-in user | `GET /bodas/{id}` `GET /bodas/{id}/reviews` |
| Buyer (no account) | `POST /public/deliveries/{id}/review` with the secret `token` from the SMS |
| Admin | `GET /admin/bodas?status=pending` `POST /admin/bodas/{id}/approve` `.../suspend` `GET /admin/deliveries` `POST /admin/deliveries/{id}/resolve` |
| Payment provider | `POST /webhooks/payments` signed with HMAC-SHA256 in `X-Signature` |
| Monitoring | `GET /healthz` |

Admin accounts can only be created from the command line, never through the API.

## Configuration

Everything is an environment variable named `MUDAALA_<SETTING>`; defaults and the full list
are in `mudaala_delivery/config.py`. The ones you will most likely change: the three secrets,
`PUBLIC_BASE_URL`, `SEARCH_RADIUS_KM`, `OFFER_TTL_SECONDS`, `BASE_FEE_UGX`, `PER_KM_FEE_UGX`,
`COMMISSION_RATE`, `NEW_BODA_VALUE_CAP_UGX`.

## Plugging in providers

Pass your own adapters when building the context (see `mudaala_delivery/wsgi.py`):

```python
from mudaala_delivery.api import create_app
from mudaala_delivery.config import Config
from mudaala_delivery.ctx import Context

ctx = Context(Config.from_env(), sms_gateway=MySmsGateway(), payment_provider=MyMomoProvider())
app = create_app(ctx=ctx)
```

- SMS gateway: `send(phone: str, body: str) -> None`, raise on failure (the worker retries).
- Payment provider: `charge(payment_id, phone, amount_ugx) -> provider_ref`. It must treat
  `payment_id` as an idempotency key, so a retry after a crash never charges twice.

## Layout

```
mudaala_delivery/
  api.py            HTTP routes, validation, errors, logging, rate limiting
  schemas.py        request validation
  services/         business rules: users, bodas, deliveries, reviews, payments, sms
  db.py, migrations/ SQLite, transactions, schema
  security.py       password hashing, tokens, PIN hashing, webhook signing
  worker.py, cli.py background worker and command line
tests/              69 tests; test_concurrency.py runs real threads
```

Timestamps are Unix seconds (UTC). Money is whole UGX.
