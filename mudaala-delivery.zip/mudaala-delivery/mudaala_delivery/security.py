import base64
import hashlib
import hmac
import secrets

import jwt

_N, _R, _P = 2**14, 8, 1


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode()


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P, dklen=32)
    return "scrypt$%d$%d$%d$%s$%s" % (_N, _R, _P, _b64(salt), _b64(dk))


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt_b64, dk_b64 = stored.split("$")
        if scheme != "scrypt":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(dk_b64)
        actual = hashlib.scrypt(
            password.encode(), salt=salt, n=int(n), r=int(r), p=int(p), dklen=len(expected)
        )
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


# Verified against when a phone number is unknown, so login timing does not reveal accounts.
DUMMY_HASH = hash_password("not-a-real-password")


def issue_access_token(secret: str, user_id: str, role: str, now: int, minutes: int) -> str:
    payload = {
        "sub": user_id,
        "role": role,
        "iat": now,
        "exp": now + minutes * 60,
        "jti": secrets.token_hex(8),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def decode_access_token(secret: str, token: str) -> dict:
    """Verify signature and required claims. Time claims (exp) are checked by the caller against
    the app clock, so a slightly fast clock on another server cannot reject a valid token."""
    return jwt.decode(
        token,
        secret,
        algorithms=["HS256"],
        options={
            "require": ["exp", "sub", "role"],
            "verify_exp": False,
            "verify_iat": False,
            "verify_nbf": False,
        },
    )


def new_opaque_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def new_pin() -> str:
    return "%04d" % secrets.randbelow(10000)


def hash_pin(secret: str, delivery_id: str, pin: str) -> str:
    msg = (delivery_id + ":" + pin).encode()
    return hmac.new(secret.encode(), msg, hashlib.sha256).hexdigest()


def sign_webhook(secret: str, body: bytes) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
