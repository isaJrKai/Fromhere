"""Mudaala delivery backend: sellers request deliveries, nearby vetted bodas accept them."""

__version__ = "0.1.0"
