"""Background worker. Run exactly ONE instance: it dispatches jobs, sends SMS and retries
mobile money charges."""

import logging
import signal
import time

from .services import deliveries, payments, sms

log = logging.getLogger("mudaala.worker")


def run_once(ctx) -> dict:
    result = {"dispatched": 0, "sms_sent": 0, "payments_started": 0}
    for key, fn in (
        ("dispatched", deliveries.process_due),
        ("sms_sent", sms.send_pending),
        ("payments_started", payments.retry_due),
    ):
        try:
            result[key] = fn(ctx)
        except Exception:
            log.exception("worker step %s failed", key)
    return result


def run_forever(ctx, interval_seconds: float = 5.0):
    stop = {"flag": False}

    def _stop(*_):
        stop["flag"] = True

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    log.info("worker started")
    while not stop["flag"]:
        started = time.monotonic()
        run_once(ctx)
        time.sleep(max(0.0, interval_seconds - (time.monotonic() - started)))
    log.info("worker stopped")
