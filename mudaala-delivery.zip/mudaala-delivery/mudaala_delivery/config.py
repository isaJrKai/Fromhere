import os
import secrets
from dataclasses import dataclass, fields


@dataclass(frozen=True)
class Config:
    env: str = "development"
    database_path: str = "mudaala.db"

    # Secrets. In production these MUST come from the environment.
    jwt_secret: str = ""
    pin_secret: str = ""
    webhook_secret: str = ""

    access_token_minutes: int = 60
    refresh_token_days: int = 30

    # Matching
    search_radius_km: float = 5.0
    offer_ttl_seconds: int = 60
    offers_per_round: int = 3
    max_dispatch_rounds: int = 3
    location_max_age_seconds: int = 120
    max_delivery_distance_km: float = 30.0

    # Pricing (UGX). Flat formula, no surge.
    base_fee_ugx: int = 2000
    per_km_fee_ugx: int = 800
    fee_rounding_ugx: int = 500
    commission_rate: float = 0.10

    # Trust ladder: how much item value a boda may carry.
    new_boda_value_cap_ugx: int = 200_000
    value_cap_step_ugx: int = 100_000
    value_cap_step_deliveries: int = 10
    max_value_cap_ugx: int = 1_000_000

    # ETA model
    avg_speed_kmh: float = 20.0
    road_factor: float = 1.4
    eta_buffer_minutes: int = 5

    # Delivery confirmation
    pin_max_attempts: int = 5

    # Reviews
    review_window_days: int = 7
    min_reviews_for_score: int = 3
    score_prior: float = 4.0
    score_prior_weight: float = 5.0

    max_open_deliveries_per_seller: int = 10

    # Phone numbers typed as 07xx... are read as this country (256 = Uganda).
    default_country_code: str = "256"
    public_base_url: str = "https://mudaala.store"

    # Abuse protection
    rate_limit_auth_per_minute: int = 10
    trust_proxy_hops: int = 0  # number of reverse proxies in front of the app

    @staticmethod
    def from_env() -> "Config":
        env = os.environ.get("MUDAALA_ENV", "development")
        values = {"env": env}
        defaults = Config()
        for f in fields(Config):
            if f.name == "env":
                continue
            raw = os.environ.get("MUDAALA_" + f.name.upper())
            if raw is None:
                continue
            # Coerce using the type of the default value (int, float or str).
            values[f.name] = type(getattr(defaults, f.name))(raw)

        secret_names = ("jwt_secret", "pin_secret", "webhook_secret")
        if env == "production":
            missing = [n for n in secret_names if len(values.get(n, "")) < 32]
            if missing:
                raise RuntimeError(
                    "Production requires secrets of at least 32 characters: "
                    + ", ".join("MUDAALA_" + n.upper() for n in missing)
                )
        else:
            for n in secret_names:
                values.setdefault(n, secrets.token_urlsafe(32))
        return Config(**values)
