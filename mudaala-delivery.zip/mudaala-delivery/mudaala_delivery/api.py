import functools
import json
import logging
import sys
import time
import uuid

from flask import Flask, g, jsonify, request
from pydantic import ValidationError
from werkzeug.middleware.proxy_fix import ProxyFix

from . import db
from .config import Config
from .ctx import Context
from .errors import ApiError
from .ratelimit import RateLimiter
from .schemas import (
    AvailabilityIn, BodaApplyIn, BuyerReviewIn, CancelIn, ConfirmIn, DeliveryIn, LocationIn,
    LoginIn, QuoteIn, RefreshIn, RegisterIn, ReplyIn, ResolveIn, ReviewIn,
)
from .services import bodas, deliveries, payments, reviews, users

log = logging.getLogger("mudaala.api")


class _JsonFormatter(logging.Formatter):
    def format(self, record):
        out = {"t": round(record.created, 3), "level": record.levelname, "logger": record.name,
               "msg": record.getMessage()}
        if record.exc_info:
            out["exc"] = self.formatException(record.exc_info)
        return json.dumps(out)


def _setup_logging():
    root = logging.getLogger()
    if not any(getattr(h, "_mudaala", False) for h in root.handlers):
        h = logging.StreamHandler(sys.stdout)
        h.setFormatter(_JsonFormatter())
        h._mudaala = True
        root.addHandler(h)
        root.setLevel(logging.INFO)


def create_app(config: Config = None, ctx: Context = None) -> Flask:
    _setup_logging()
    ctx = ctx or Context(config or Config.from_env())
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 64 * 1024
    if ctx.config.trust_proxy_hops:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=ctx.config.trust_proxy_hops)
    app.extensions["ctx"] = ctx
    limiter = RateLimiter(ctx.clock)

    # ------------------------------------------------------------ plumbing

    @app.before_request
    def _start():
        g.request_id = request.headers.get("X-Request-Id", "")[:64] or uuid.uuid4().hex[:16]
        g.started = time.monotonic()

    @app.after_request
    def _finish(resp):
        resp.headers["X-Request-Id"] = g.get("request_id", "")
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        if request.path != "/healthz":
            log.info("%s %s %s %dms rid=%s", request.method, request.path, resp.status_code,
                     (time.monotonic() - g.get("started", time.monotonic())) * 1000, g.get("request_id"))
        return resp

    @app.errorhandler(ApiError)
    def _api_error(e):
        return jsonify(e.to_dict()), e.status

    @app.errorhandler(ValidationError)
    def _invalid(e):
        details = [{"field": ".".join(str(p) for p in err["loc"]), "message": err["msg"]} for err in e.errors()]
        return jsonify(ApiError(422, "validation_error", "Some fields are invalid.", details).to_dict()), 422

    @app.errorhandler(404)
    def _nf(_):
        return jsonify(ApiError(404, "not_found", "Not found.").to_dict()), 404

    @app.errorhandler(405)
    def _na(_):
        return jsonify(ApiError(405, "method_not_allowed", "Method not allowed.").to_dict()), 405

    @app.errorhandler(413)
    def _big(_):
        return jsonify(ApiError(413, "too_large", "Request body too large.").to_dict()), 413

    @app.errorhandler(Exception)
    def _boom(e):
        log.exception("unhandled error rid=%s", g.get("request_id"))
        body = ApiError(500, "internal_error", "Something went wrong. Quote this id to support: %s" % g.get("request_id")).to_dict()
        return jsonify(body), 500

    def body(model):
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            raise ApiError(400, "bad_json", "Send a JSON object.")
        return model.model_validate(data)

    def limit(key_suffix: str, per_minute: int):
        if not limiter.allow("%s:%s" % (key_suffix, request.remote_addr), per_minute):
            raise ApiError(429, "rate_limited", "Too many attempts. Wait a minute and try again.")

    def auth(*roles):
        def deco(fn):
            @functools.wraps(fn)
            def wrapper(*a, **kw):
                header = request.headers.get("Authorization", "")
                if not header.startswith("Bearer "):
                    raise ApiError(401, "unauthorized", "Authentication required.")
                user = users.authenticate(ctx, header[7:].strip())
                if roles and user["role"] not in roles:
                    raise ApiError(403, "forbidden", "You do not have access to this.")
                g.user = user
                return fn(*a, **kw)
            return wrapper
        return deco

    def int_arg(name, default=None):
        raw = request.args.get(name)
        if raw is None:
            return default
        try:
            return int(raw)
        except ValueError:
            raise ApiError(422, "invalid_query", "%s must be a number." % name) from None

    # ------------------------------------------------------------ health

    @app.get("/healthz")
    def health():
        ctx.db.execute("SELECT 1").fetchone()
        return jsonify({"status": "ok"})

    # ------------------------------------------------------------ auth

    @app.post("/v1/auth/register")
    def register():
        limit("register", ctx.config.rate_limit_auth_per_minute)
        d = body(RegisterIn)
        return jsonify(users.register(ctx, d.phone, d.name, d.password, d.role)), 201

    @app.post("/v1/auth/login")
    def login():
        limit("login", ctx.config.rate_limit_auth_per_minute)
        d = body(LoginIn)
        # Per-account limit as well, so spreading guesses over many IPs does not help.
        if not limiter.allow("login-phone:" + d.phone.replace(" ", ""), ctx.config.rate_limit_auth_per_minute):
            raise ApiError(429, "rate_limited", "Too many attempts. Wait a minute and try again.")
        return jsonify(users.login(ctx, d.phone, d.password))

    @app.post("/v1/auth/refresh")
    def refresh():
        limit("refresh", ctx.config.rate_limit_auth_per_minute * 3)
        return jsonify(users.refresh(ctx, body(RefreshIn).refresh_token))

    @app.post("/v1/auth/logout")
    def logout():
        users.logout(ctx, body(RefreshIn).refresh_token)
        return jsonify({"ok": True})

    # ------------------------------------------------------------ bodas

    @app.post("/v1/bodas/me/profile")
    @auth("boda")
    def boda_apply():
        d = body(BodaApplyIn)
        return jsonify(bodas.apply(ctx, g.user, d.national_id, d.plate_number, d.guarantor_name, d.guarantor_phone)), 201

    @app.get("/v1/bodas/me")
    @auth("boda")
    def boda_me():
        return jsonify(bodas.profile_for_owner(ctx, g.user))

    @app.put("/v1/bodas/me/availability")
    @auth("boda")
    def boda_availability():
        return jsonify(bodas.set_available(ctx, g.user, body(AvailabilityIn).available))

    @app.post("/v1/bodas/me/location")
    @auth("boda")
    def boda_location():
        d = body(LocationIn)
        return jsonify(bodas.ping(ctx, g.user, d.lat, d.lng))

    @app.get("/v1/bodas/me/offers")
    @auth("boda")
    def boda_offers():
        return jsonify({"offers": deliveries.offers_for_boda(ctx, g.user)})

    @app.get("/v1/bodas/me/active")
    @auth("boda")
    def boda_active():
        return jsonify({"delivery": deliveries.active_for_boda(ctx, g.user)})

    @app.get("/v1/bodas/me/history")
    @auth("boda")
    def boda_history():
        return jsonify({"deliveries": deliveries.history_for_boda(ctx, g.user, int_arg("limit", 20))})

    @app.get("/v1/bodas/me/earnings")
    @auth("boda")
    def boda_earnings():
        return jsonify(payments.earnings_for_boda(ctx, g.user["id"]))

    @app.get("/v1/bodas/<boda_id>")
    @auth()
    def boda_public(boda_id):
        return jsonify(bodas.public_summary(ctx, boda_id))

    @app.get("/v1/bodas/<boda_id>/reviews")
    @auth()
    def boda_reviews(boda_id):
        bodas.public_summary(ctx, boda_id)  # 404 for unknown or unapproved riders
        return jsonify({"reviews": reviews.list_for_boda(ctx, boda_id, int_arg("limit", 20), int_arg("before"))})

    @app.post("/v1/reviews/<review_id>/reply")
    @auth("boda")
    def review_reply(review_id):
        return jsonify(reviews.reply(ctx, g.user, review_id, body(ReplyIn).text))

    # ------------------------------------------------------------ deliveries

    @app.post("/v1/quote")
    @auth("seller")
    def quote():
        d = body(QuoteIn)
        return jsonify(deliveries.estimate(ctx, (d.pickup_lat, d.pickup_lng), (d.dropoff_lat, d.dropoff_lng)))

    @app.post("/v1/deliveries")
    @auth("seller")
    def delivery_create():
        key = request.headers.get("Idempotency-Key")
        if key is not None and not (8 <= len(key) <= 80):
            raise ApiError(422, "invalid_idempotency_key", "Idempotency-Key must be 8 to 80 characters.")
        out, created = deliveries.create(ctx, g.user, body(DeliveryIn).model_dump(), key)
        return jsonify(out), 201 if created else 200

    @app.get("/v1/deliveries")
    @auth("seller")
    def delivery_list():
        return jsonify({"deliveries": deliveries.list_for_seller(
            ctx, g.user, request.args.get("status"), int_arg("limit", 20), int_arg("before"))})

    @app.get("/v1/deliveries/<delivery_id>")
    @auth("seller", "boda", "admin")
    def delivery_get(delivery_id):
        return jsonify(deliveries.get_for_user(ctx, g.user, delivery_id))

    @app.post("/v1/deliveries/<delivery_id>/accept")
    @auth("boda")
    def delivery_accept(delivery_id):
        return jsonify(deliveries.accept(ctx, g.user, delivery_id))

    @app.post("/v1/deliveries/<delivery_id>/decline")
    @auth("boda")
    def delivery_decline(delivery_id):
        return jsonify(deliveries.decline(ctx, g.user, delivery_id))

    @app.post("/v1/deliveries/<delivery_id>/pickup")
    @auth("boda")
    def delivery_pickup(delivery_id):
        return jsonify(deliveries.pickup(ctx, g.user, delivery_id))

    @app.post("/v1/deliveries/<delivery_id>/confirm")
    @auth("boda")
    def delivery_confirm(delivery_id):
        return jsonify(deliveries.confirm(ctx, g.user, delivery_id, body(ConfirmIn).pin))

    @app.post("/v1/deliveries/<delivery_id>/cancel")
    @auth("seller", "boda")
    def delivery_cancel(delivery_id):
        reason = body(CancelIn).reason if request.data else None
        return jsonify(deliveries.cancel(ctx, g.user, delivery_id, reason))

    @app.post("/v1/deliveries/<delivery_id>/review")
    @auth("seller")
    def delivery_review(delivery_id):
        d = body(ReviewIn)
        return jsonify(reviews.create_as_seller(ctx, g.user, delivery_id, d.courtesy, d.condition_ok, d.comment, d.damage_note)), 201

    @app.post("/v1/public/deliveries/<delivery_id>/review")
    def delivery_review_buyer(delivery_id):
        limit("buyer-review", 20)
        d = body(BuyerReviewIn)
        return jsonify(reviews.create_as_buyer(ctx, delivery_id, d.token, d.courtesy, d.condition_ok, d.comment, d.damage_note)), 201

    # ------------------------------------------------------------ admin

    @app.get("/v1/admin/bodas")
    @auth("admin")
    def admin_bodas():
        status = request.args.get("status", "pending")
        if status not in ("pending", "approved", "suspended"):
            raise ApiError(422, "invalid_query", "Unknown status.")
        return jsonify({"bodas": bodas.list_by_status(ctx, status, int_arg("limit", 50))})

    @app.post("/v1/admin/bodas/<boda_id>/approve")
    @auth("admin")
    def admin_approve(boda_id):
        return jsonify(bodas.set_status(ctx, g.user, boda_id, "approved"))

    @app.post("/v1/admin/bodas/<boda_id>/suspend")
    @auth("admin")
    def admin_suspend(boda_id):
        return jsonify(bodas.set_status(ctx, g.user, boda_id, "suspended"))

    @app.get("/v1/admin/deliveries")
    @auth("admin")
    def admin_deliveries():
        return jsonify({"deliveries": deliveries.list_all(ctx, g.user, request.args.get("status"), int_arg("limit", 50))})

    @app.post("/v1/admin/deliveries/<delivery_id>/resolve")
    @auth("admin")
    def admin_resolve(delivery_id):
        d = body(ResolveIn)
        return jsonify(deliveries.resolve(ctx, g.user, delivery_id, d.outcome, d.note))

    # ------------------------------------------------------------ webhooks

    @app.post("/v1/webhooks/payments")
    def payment_webhook():
        return jsonify(payments.handle_webhook(ctx, request.get_data(), request.headers.get("X-Signature", "")))

    return app
