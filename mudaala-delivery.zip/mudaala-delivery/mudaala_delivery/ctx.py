import logging
import threading
import time

from . import db
from .config import Config

log = logging.getLogger("mudaala")


class LogSmsGateway:
    """Development gateway: writes messages to the log. Replace with a real SMS provider."""

    def send(self, phone: str, body: str) -> None:
        log.info("sms to=%s body_chars=%d", phone, len(body))


class UnconfiguredPaymentProvider:
    """Used until a real mobile money provider is wired in. Never pretends a charge worked."""

    def charge(self, payment_id: str, phone: str, amount_ugx: int) -> str:
        raise RuntimeError("No payment provider configured")


class Context:
    """Everything a service needs: config, a clock, a per-thread database connection and
    the outside-world adapters. Tests swap the clock and the adapters."""

    def __init__(self, config: Config, clock=None, sms_gateway=None, payment_provider=None):
        self.config = config
        self.clock = clock or time.time
        self.sms_gateway = sms_gateway or LogSmsGateway()
        self.payment_provider = payment_provider or UnconfiguredPaymentProvider()
        self._local = threading.local()

    @property
    def db(self):
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = db.connect(self.config.database_path)
            self._local.conn = conn
        return conn

    def now(self) -> int:
        return int(self.clock())
