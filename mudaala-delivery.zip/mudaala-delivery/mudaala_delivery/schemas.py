from typing import Annotated, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictInt

Lat = Annotated[float, Field(ge=-90, le=90, allow_inf_nan=False)]
Lng = Annotated[float, Field(ge=-180, le=180, allow_inf_nan=False)]


class _In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class RegisterIn(_In):
    phone: str = Field(min_length=7, max_length=20)
    name: str = Field(min_length=2, max_length=80)
    password: str = Field(min_length=8, max_length=128)
    role: Literal["seller", "boda"]


class LoginIn(_In):
    phone: str = Field(min_length=7, max_length=20)
    password: str = Field(min_length=1, max_length=128)


class RefreshIn(_In):
    refresh_token: str = Field(min_length=10, max_length=200)


class BodaApplyIn(_In):
    national_id: str = Field(min_length=8, max_length=24)
    plate_number: str = Field(min_length=5, max_length=14)
    guarantor_name: str = Field(min_length=2, max_length=80)
    guarantor_phone: str = Field(min_length=7, max_length=20)


class AvailabilityIn(_In):
    available: StrictBool


class LocationIn(_In):
    lat: Lat
    lng: Lng


class DeliveryIn(_In):
    pickup_lat: Lat
    pickup_lng: Lng
    pickup_landmark: str = Field(min_length=2, max_length=120)
    dropoff_lat: Lat
    dropoff_lng: Lng
    dropoff_landmark: str = Field(min_length=2, max_length=120)
    buyer_name: str = Field(min_length=2, max_length=80)
    buyer_phone: str = Field(min_length=7, max_length=20)
    item_description: str = Field(min_length=2, max_length=200)
    item_value_ugx: StrictInt = Field(ge=0, le=50_000_000)
    payment_method: Literal["cash", "mobile_money"]


class QuoteIn(_In):
    pickup_lat: Lat
    pickup_lng: Lng
    dropoff_lat: Lat
    dropoff_lng: Lng


class ConfirmIn(_In):
    pin: str = Field(pattern=r"^\d{4}$")


class CancelIn(_In):
    reason: Optional[str] = Field(default=None, max_length=200)


class ReviewIn(_In):
    courtesy: StrictInt = Field(ge=1, le=5)
    condition_ok: StrictBool
    comment: Optional[str] = Field(default=None, max_length=500)
    damage_note: Optional[str] = Field(default=None, max_length=300)


class BuyerReviewIn(ReviewIn):
    token: str = Field(min_length=10, max_length=200)


class ReplyIn(_In):
    text: str = Field(min_length=1, max_length=500)


class ResolveIn(_In):
    outcome: Literal["DELIVERED", "FAILED", "CANCELLED"]
    note: str = Field(min_length=3, max_length=300)
