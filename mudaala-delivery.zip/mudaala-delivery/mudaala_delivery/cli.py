import argparse
import getpass
import os
import sys

from . import db
from .config import Config
from .ctx import Context
from .errors import ApiError


def main(argv=None):
    p = argparse.ArgumentParser(prog="mudaala_delivery")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("migrate", help="create or update the database schema")
    a = sub.add_parser("create-admin", help="create an admin account")
    a.add_argument("--phone", required=True)
    a.add_argument("--name", required=True)
    sub.add_parser("worker", help="run the background worker (one instance only)")
    s = sub.add_parser("serve", help="run the development server (use gunicorn in production)")
    s.add_argument("--port", type=int, default=8000)
    args = p.parse_args(argv)

    cfg = Config.from_env()
    ctx = Context(cfg)

    if args.cmd == "migrate":
        ran = db.migrate(ctx.db)
        print("applied: " + (", ".join(ran) if ran else "nothing to do"))
    elif args.cmd == "create-admin":
        from .services import users

        password = os.environ.get("MUDAALA_ADMIN_PASSWORD") or getpass.getpass("Password (min 12 chars): ")
        if len(password) < 12:
            sys.exit("Admin password must be at least 12 characters.")
        try:
            print(users.create_admin(ctx, args.phone, args.name, password))
        except ApiError as e:
            sys.exit(e.message)
    elif args.cmd == "worker":
        from . import worker

        db.migrate(ctx.db)
        worker.run_forever(ctx)
    elif args.cmd == "serve":
        from .api import create_app

        if cfg.env == "production":
            sys.exit("Use gunicorn in production: gunicorn 'mudaala_delivery.wsgi:app'")
        create_app(ctx=ctx).run(port=args.port)


if __name__ == "__main__":
    main()
