import re

from .errors import ApiError


def normalize_phone(raw: str, default_country_code: str) -> str:
    """Return E.164 (+256700000000). Accepts 0700000000, 256700000000, +256 700 000 000."""
    s = re.sub(r"[\s\-().]", "", raw or "")
    if s.startswith("00"):
        s = "+" + s[2:]
    elif re.fullmatch(r"0\d{9}", s):
        s = "+" + default_country_code + s[1:]
    elif re.fullmatch(r"[1-9]\d{9,14}", s):
        s = "+" + s
    if not re.fullmatch(r"\+[1-9]\d{9,14}", s):
        raise ApiError(422, "invalid_phone", "Enter a valid phone number, for example 0700123456.")
    return s


def normalize_plate(raw: str) -> str:
    s = re.sub(r"[\s\-]", "", raw or "").upper()
    if not re.fullmatch(r"[A-Z0-9]{5,10}", s):
        raise ApiError(422, "invalid_plate", "Enter a valid number plate.")
    return s


def normalize_national_id(raw: str) -> str:
    s = re.sub(r"\s", "", raw or "").upper()
    if not re.fullmatch(r"[A-Z0-9]{8,20}", s):
        raise ApiError(422, "invalid_national_id", "Enter a valid national ID number.")
    return s
