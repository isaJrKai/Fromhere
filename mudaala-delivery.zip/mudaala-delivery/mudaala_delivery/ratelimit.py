import threading
from collections import defaultdict, deque


class RateLimiter:
    """Sliding-window limiter held in process memory.

    Each worker process keeps its own counts, so the effective limit is (limit x workers).
    Good enough for one small server; use a shared store such as Redis when you scale out."""

    def __init__(self, clock):
        self._clock = clock
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key: str, limit: int, window_seconds: int = 60) -> bool:
        now = self._clock()
        with self._lock:
            q = self._hits[key]
            while q and q[0] <= now - window_seconds:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            if len(self._hits) > 50_000:  # bound memory under a flood of distinct keys
                for k in [k for k, v in self._hits.items() if not v][:10_000]:
                    self._hits.pop(k, None)
            return True
