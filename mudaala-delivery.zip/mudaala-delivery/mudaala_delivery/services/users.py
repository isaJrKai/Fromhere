import sqlite3

import jwt

from .. import db, security
from ..errors import ApiError
from ..validation import normalize_phone
from .common import new_id


def _unauth(msg="Authentication required."):
    return ApiError(401, "unauthorized", msg)


def _create(ctx, phone, name, password, role):
    phone = normalize_phone(phone, ctx.config.default_country_code)
    uid, now = new_id(), ctx.now()
    pw_hash = security.hash_password(password)  # slow on purpose; done outside the transaction
    try:
        with db.transaction(ctx.db) as c:
            c.execute(
                "INSERT INTO users(id, phone, name, password_hash, role, created_at) VALUES (?,?,?,?,?,?)",
                (uid, phone, name, pw_hash, role, now),
            )
    except sqlite3.IntegrityError:
        raise ApiError(409, "phone_taken", "An account with this phone number already exists.") from None
    return {"id": uid, "phone": phone, "name": name, "role": role}


def register(ctx, phone, name, password, role):
    if role not in ("seller", "boda"):
        raise ApiError(422, "invalid_role", "Role must be seller or boda.")
    return _create(ctx, phone, name, password, role)


def create_admin(ctx, phone, name, password):
    """Admins can only be created from the command line, never through the API."""
    return _create(ctx, phone, name, password, "admin")


def _issue_tokens(ctx, c, user):
    cfg, now = ctx.config, ctx.now()
    access = security.issue_access_token(
        cfg.jwt_secret, user["id"], user["role"], now, cfg.access_token_minutes
    )
    refresh = security.new_opaque_token()
    c.execute(
        "INSERT INTO refresh_tokens(id, user_id, token_hash, expires_at, created_at) VALUES (?,?,?,?,?)",
        (new_id(), user["id"], security.hash_token(refresh), now + cfg.refresh_token_days * 86400, now),
    )
    return {
        "access_token": access,
        "refresh_token": refresh,
        "token_type": "Bearer",
        "expires_in": cfg.access_token_minutes * 60,
    }


def login(ctx, phone, password):
    phone = normalize_phone(phone, ctx.config.default_country_code)
    user = ctx.db.execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()
    # Always run a hash check so an unknown number takes as long as a wrong password.
    stored = user["password_hash"] if user else security.DUMMY_HASH
    ok = security.verify_password(password, stored)
    if not user or not ok or not user["is_active"]:
        raise ApiError(401, "invalid_credentials", "Wrong phone number or password.")
    with db.transaction(ctx.db) as c:
        return _issue_tokens(ctx, c, user)


def refresh(ctx, refresh_token):
    h, now = security.hash_token(refresh_token), ctx.now()
    problem, tokens = None, None
    with db.transaction(ctx.db) as c:
        row = c.execute("SELECT * FROM refresh_tokens WHERE token_hash=?", (h,)).fetchone()
        if row is None:
            problem = "Invalid refresh token."
        elif row["revoked"]:
            # A used token came back: it may have been stolen. Sign the user out everywhere.
            c.execute("UPDATE refresh_tokens SET revoked=1 WHERE user_id=?", (row["user_id"],))
            problem = "Refresh token already used. Please log in again."
        elif row["expires_at"] <= now:
            problem = "Refresh token expired. Please log in again."
        else:
            user = c.execute("SELECT * FROM users WHERE id=?", (row["user_id"],)).fetchone()
            if not user or not user["is_active"]:
                problem = "Account disabled."
            else:
                cur = c.execute(
                    "UPDATE refresh_tokens SET revoked=1 WHERE id=? AND revoked=0", (row["id"],)
                )
                if cur.rowcount != 1:
                    problem = "Invalid refresh token."
                else:
                    tokens = _issue_tokens(ctx, c, user)
    if problem:
        raise _unauth(problem)
    return tokens


def logout(ctx, refresh_token):
    with db.transaction(ctx.db) as c:
        c.execute(
            "UPDATE refresh_tokens SET revoked=1 WHERE token_hash=?", (security.hash_token(refresh_token),)
        )


def authenticate(ctx, token):
    try:
        claims = security.decode_access_token(ctx.config.jwt_secret, token)
    except jwt.PyJWTError:
        raise _unauth("Invalid token.") from None
    if claims["exp"] <= ctx.now():
        raise _unauth("Token expired.")
    user = ctx.db.execute("SELECT * FROM users WHERE id=?", (claims["sub"],)).fetchone()
    if not user or not user["is_active"]:
        raise _unauth("Account disabled.")
    return dict(user)  # role comes from the database, not the token, so changes apply at once


def deactivate(ctx, user_id):
    with db.transaction(ctx.db) as c:
        c.execute("UPDATE users SET is_active=0 WHERE id=?", (user_id,))
        c.execute("UPDATE refresh_tokens SET revoked=1 WHERE user_id=?", (user_id,))
        c.execute("UPDATE boda_profiles SET is_available=0 WHERE user_id=?", (user_id,))
