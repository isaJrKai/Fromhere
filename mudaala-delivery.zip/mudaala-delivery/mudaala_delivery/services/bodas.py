import sqlite3

from .. import db, geo
from ..errors import ApiError
from ..validation import normalize_national_id, normalize_phone, normalize_plate
from . import reviews


def value_cap(cfg, completed: int) -> int:
    """Trust ladder: new riders carry small items; the cap grows with successful deliveries."""
    steps = completed // cfg.value_cap_step_deliveries
    return min(cfg.max_value_cap_ugx, cfg.new_boda_value_cap_ugx + steps * cfg.value_cap_step_ugx)


def completed_count(c, boda_id) -> int:
    return c.execute(
        "SELECT COUNT(*) FROM deliveries WHERE boda_id=? AND status='DELIVERED'", (boda_id,)
    ).fetchone()[0]


def get_profile(c, boda_id):
    return c.execute("SELECT * FROM boda_profiles WHERE user_id=?", (boda_id,)).fetchone()


def apply(ctx, user, national_id, plate, guarantor_name, guarantor_phone):
    if user["role"] != "boda":
        raise ApiError(403, "forbidden", "Only boda accounts can apply.")
    nid = normalize_national_id(national_id)
    plate = normalize_plate(plate)
    gphone = normalize_phone(guarantor_phone, ctx.config.default_country_code)
    if gphone == user["phone"]:
        raise ApiError(422, "invalid_guarantor", "The guarantor must be someone other than you.")
    try:
        with db.transaction(ctx.db) as c:
            c.execute(
                "INSERT INTO boda_profiles(user_id, national_id, plate_number, guarantor_name,"
                " guarantor_phone, created_at) VALUES (?,?,?,?,?,?)",
                (user["id"], nid, plate, guarantor_name, gphone, ctx.now()),
            )
    except sqlite3.IntegrityError as e:
        if "plate_number" in str(e):
            raise ApiError(409, "plate_taken", "This number plate is already registered.") from None
        raise ApiError(409, "already_applied", "You have already applied.") from None
    return profile_for_owner(ctx, user)


def _mask(value: str) -> str:
    return value[:2] + "*" * max(0, len(value) - 4) + value[-2:]


def profile_for_owner(ctx, user):
    p = get_profile(ctx.db, user["id"])
    if p is None:
        raise ApiError(404, "no_profile", "Submit your boda application first.")
    done = completed_count(ctx.db, user["id"])
    return {
        "id": user["id"],
        "name": user["name"],
        "status": p["status"],
        "is_available": bool(p["is_available"]),
        "plate_number": p["plate_number"],
        "national_id": _mask(p["national_id"]),
        "guarantor_name": p["guarantor_name"],
        "completed_deliveries": done,
        "value_cap_ugx": value_cap(ctx.config, done),
        "last_ping_at": p["last_ping_at"],
        "rating": reviews.score(ctx, user["id"]),
    }


def public_summary(ctx, boda_id):
    row = ctx.db.execute(
        "SELECT u.name, bp.status FROM users u JOIN boda_profiles bp ON bp.user_id=u.id WHERE u.id=?",
        (boda_id,),
    ).fetchone()
    if row is None or row["status"] != "approved":
        raise ApiError(404, "not_found", "Boda not found.")
    return {
        "id": boda_id,
        "name": row["name"],
        "completed_deliveries": completed_count(ctx.db, boda_id),
        "rating": reviews.score(ctx, boda_id),
    }


def set_status(ctx, admin, boda_id, status):
    """Admin approves or suspends. Suspending also takes the boda off the map immediately."""
    if status not in ("approved", "suspended"):
        raise ApiError(422, "invalid_status", "Status must be approved or suspended.")
    now = ctx.now()
    with db.transaction(ctx.db) as c:
        p = get_profile(c, boda_id)
        if p is None:
            raise ApiError(404, "not_found", "Boda not found.")
        if status == "approved":
            c.execute(
                "UPDATE boda_profiles SET status='approved', approved_by=?, approved_at=? WHERE user_id=?",
                (admin["id"], now, boda_id),
            )
        else:
            c.execute(
                "UPDATE boda_profiles SET status='suspended', is_available=0 WHERE user_id=?", (boda_id,)
            )
    return {"id": boda_id, "status": status}


def list_by_status(ctx, status, limit=50):
    rows = ctx.db.execute(
        "SELECT u.id, u.name, u.phone, bp.plate_number, bp.national_id, bp.guarantor_name,"
        " bp.guarantor_phone, bp.status, bp.created_at FROM boda_profiles bp"
        " JOIN users u ON u.id=bp.user_id WHERE bp.status=? ORDER BY bp.created_at LIMIT ?",
        (status, limit),
    ).fetchall()
    return [dict(r) for r in rows]


def set_available(ctx, user, available: bool):
    with db.transaction(ctx.db) as c:
        p = get_profile(c, user["id"])
        if p is None or p["status"] != "approved":
            raise ApiError(403, "not_approved", "Your account has not been approved yet.")
        c.execute("UPDATE boda_profiles SET is_available=? WHERE user_id=?", (1 if available else 0, user["id"]))
    return {"is_available": available}


def ping(ctx, user, lat, lng):
    with db.transaction(ctx.db) as c:
        cur = c.execute(
            "UPDATE boda_profiles SET last_lat=?, last_lng=?, last_ping_at=? WHERE user_id=? AND status='approved'",
            (lat, lng, ctx.now(), user["id"]),
        )
        if cur.rowcount != 1:
            raise ApiError(403, "not_approved", "Your account has not been approved yet.")
    return {"ok": True}


def find_candidates(ctx, c, lat, lng, item_value, exclude_ids=()):
    """Available, approved bodas with a fresh location near (lat, lng), nearest first, who are
    free (no active delivery) and whose trust level allows carrying this item's value."""
    cfg, now = ctx.config, ctx.now()
    la0, la1, ln0, ln1 = geo.bounding_box(lat, lng, cfg.search_radius_km)
    rows = c.execute(
        "SELECT bp.user_id, bp.last_lat, bp.last_lng FROM boda_profiles bp"
        " JOIN users u ON u.id=bp.user_id"
        " WHERE bp.status='approved' AND bp.is_available=1 AND u.is_active=1"
        "   AND bp.last_ping_at>=?"
        "   AND bp.last_lat BETWEEN ? AND ? AND bp.last_lng BETWEEN ? AND ?"
        "   AND NOT EXISTS (SELECT 1 FROM deliveries d WHERE d.boda_id=bp.user_id"
        "                   AND d.status IN ('ASSIGNED','PICKED_UP'))",
        (now - cfg.location_max_age_seconds, la0, la1, ln0, ln1),
    ).fetchall()
    near = []
    for r in rows:
        if r["user_id"] in exclude_ids:
            continue
        dist = geo.haversine_km(lat, lng, r["last_lat"], r["last_lng"])
        if dist <= cfg.search_radius_km:
            near.append((dist, r["user_id"]))
    if not near:
        return []
    near.sort()
    ids = [i for _, i in near]
    marks = ",".join("?" * len(ids))
    counts = {
        r["boda_id"]: r["n"]
        for r in c.execute(
            "SELECT boda_id, COUNT(*) AS n FROM deliveries WHERE status='DELIVERED'"
            " AND boda_id IN (" + marks + ") GROUP BY boda_id",
            ids,
        )
    }
    return [
        (bid, round(dist, 2))
        for dist, bid in near
        if item_value <= value_cap(cfg, counts.get(bid, 0))
    ]
