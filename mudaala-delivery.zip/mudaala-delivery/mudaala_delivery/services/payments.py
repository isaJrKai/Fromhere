"""Delivery fee payments.

Cash fees are recorded as paid when the delivery is confirmed. Mobile money fees are charged
through a provider adapter (see ctx.payment_provider) and settled by a signed webhook.

Provider contract: charge(payment_id, phone, amount_ugx) -> provider_ref. The provider MUST
treat payment_id as an idempotency key, so a retry after a crash never charges twice."""

import hmac
import json
import logging
import sqlite3

from .. import db, security
from ..errors import ApiError
from .common import new_id

log = logging.getLogger("mudaala.payments")
MAX_ATTEMPTS = 5
STUCK_AFTER_SECONDS = 300


def create_for_delivery(ctx, c, d):
    """Called inside the transaction that marks a delivery DELIVERED."""
    now, cfg = ctx.now(), ctx.config
    fee = d["fee_ugx"]
    commission = int(round(fee * cfg.commission_rate))
    status = "paid" if d["payment_method"] == "cash" else "pending"
    c.execute(
        "INSERT INTO payments(id, delivery_id, method, fee_ugx, commission_ugx, boda_earning_ugx,"
        " status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
        (new_id(), d["id"], d["payment_method"], fee, commission, fee - commission, status, now, now),
    )


def start(ctx, delivery_id) -> bool:
    """Charge one pending mobile money payment. Safe to call repeatedly and from several
    processes: the claim step lets only one caller proceed."""
    now = ctx.now()
    with db.transaction(ctx.db) as c:
        p = c.execute(
            "SELECT p.*, u.phone AS seller_phone FROM payments p"
            " JOIN deliveries d ON d.id=p.delivery_id JOIN users u ON u.id=d.seller_id"
            " WHERE p.delivery_id=? AND p.method='mobile_money'",
            (delivery_id,),
        ).fetchone()
        if p is None:
            return False
        claimable = p["status"] == "pending" or (
            p["status"] == "processing"
            and p["provider_ref"] is None
            and p["updated_at"] < now - STUCK_AFTER_SECONDS
        )
        if not claimable:
            return False
        c.execute(
            "UPDATE payments SET status='processing', attempts=attempts+1, updated_at=? WHERE id=?",
            (now, p["id"]),
        )
    try:
        ref = ctx.payment_provider.charge(p["id"], p["seller_phone"], p["fee_ugx"])
    except Exception:
        log.exception("charge failed payment=%s", p["id"])
        final = "failed" if p["attempts"] + 1 >= MAX_ATTEMPTS else "pending"
        with db.transaction(ctx.db) as c:
            c.execute(
                "UPDATE payments SET status=?, updated_at=? WHERE id=? AND status='processing'",
                (final, ctx.now(), p["id"]),
            )
        return False
    with db.transaction(ctx.db) as c:
        c.execute(
            "UPDATE payments SET provider_ref=?, updated_at=? WHERE id=? AND status='processing'",
            (ref, ctx.now(), p["id"]),
        )
    return True


def retry_due(ctx, limit=25) -> int:
    now = ctx.now()
    rows = ctx.db.execute(
        "SELECT delivery_id FROM payments WHERE method='mobile_money' AND"
        " (status='pending' OR (status='processing' AND provider_ref IS NULL AND updated_at<?))"
        " ORDER BY created_at LIMIT ?",
        (now - STUCK_AFTER_SECONDS, limit),
    ).fetchall()
    return sum(1 for r in rows if start(ctx, r["delivery_id"]))


def handle_webhook(ctx, raw_body: bytes, signature: str):
    expected = security.sign_webhook(ctx.config.webhook_secret, raw_body)
    if not signature or not hmac.compare_digest(expected, signature):
        raise ApiError(401, "bad_signature", "Invalid webhook signature.")
    try:
        evt = json.loads(raw_body)
        event_id, ref, status = str(evt["event_id"]), str(evt["provider_ref"]), evt["status"]
    except (ValueError, KeyError, TypeError):
        raise ApiError(400, "bad_payload", "Malformed webhook payload.") from None
    if status not in ("paid", "failed"):
        raise ApiError(400, "bad_payload", "Unknown payment status.")
    now = ctx.now()
    with db.transaction(ctx.db) as c:
        try:
            c.execute("INSERT INTO webhook_events(event_id, received_at) VALUES (?,?)", (event_id, now))
        except sqlite3.IntegrityError:
            return {"status": "duplicate"}  # provider retried; already handled
        cur = c.execute(
            "UPDATE payments SET status=?, updated_at=? WHERE provider_ref=? AND status='processing'",
            (status, now, ref),
        )
    return {"status": "applied" if cur.rowcount == 1 else "ignored"}


def get_for_delivery(c, delivery_id):
    row = c.execute("SELECT * FROM payments WHERE delivery_id=?", (delivery_id,)).fetchone()
    return dict(row) if row else None


def earnings_for_boda(ctx, boda_id):
    row = ctx.db.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(p.fee_ugx),0) AS fees,"
        " COALESCE(SUM(p.commission_ugx),0) AS commission, COALESCE(SUM(p.boda_earning_ugx),0) AS net"
        " FROM payments p JOIN deliveries d ON d.id=p.delivery_id"
        " WHERE d.boda_id=? AND p.status='paid'",
        (boda_id,),
    ).fetchone()
    return {
        "paid_deliveries": row["n"],
        "total_fees_ugx": row["fees"],
        "total_commission_ugx": row["commission"],
        "total_earnings_ugx": row["net"],
    }
