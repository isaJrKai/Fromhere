import uuid


def new_id() -> str:
    return uuid.uuid4().hex


def record_event(c, delivery_id, from_status, to_status, actor_id, note, now):
    c.execute(
        "INSERT INTO delivery_events(delivery_id, from_status, to_status, actor_id, note, created_at)"
        " VALUES (?,?,?,?,?,?)",
        (delivery_id, from_status, to_status, actor_id, note, now),
    )


def user_phone(c, user_id):
    row = c.execute("SELECT phone FROM users WHERE id=?", (user_id,)).fetchone()
    return row["phone"] if row else None
