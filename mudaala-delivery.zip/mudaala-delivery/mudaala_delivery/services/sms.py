"""SMS goes through a transactional outbox: a message row is written in the same transaction
as the change that caused it, and the worker sends it afterwards. A crash can delay a message
but never lose it or send one for a change that was rolled back."""

import logging

from .. import db

log = logging.getLogger("mudaala.sms")
MAX_ATTEMPTS = 5


def queue(c, phone: str, body: str, now: int) -> None:
    if phone:
        c.execute(
            "INSERT INTO sms_outbox(to_phone, body, created_at) VALUES (?,?,?)", (phone, body, now)
        )


def send_pending(ctx, limit: int = 50) -> int:
    """Send queued messages. Run from ONE worker process. Returns how many were sent."""
    rows = ctx.db.execute(
        "SELECT id, to_phone, body, attempts FROM sms_outbox WHERE status='queued' ORDER BY id LIMIT ?",
        (limit,),
    ).fetchall()
    sent = 0
    for r in rows:
        try:
            ctx.sms_gateway.send(r["to_phone"], r["body"])
        except Exception:
            log.exception("sms send failed id=%s", r["id"])
            status = "failed" if r["attempts"] + 1 >= MAX_ATTEMPTS else "queued"
            with db.transaction(ctx.db) as c:
                c.execute(
                    "UPDATE sms_outbox SET attempts=attempts+1, status=? WHERE id=?", (status, r["id"])
                )
            continue
        # Overwrite the body once sent so delivery PINs do not sit in the database.
        with db.transaction(ctx.db) as c:
            c.execute(
                "UPDATE sms_outbox SET status='sent', sent_at=?, attempts=attempts+1, body='[sent]' WHERE id=?",
                (ctx.now(), r["id"]),
            )
        sent += 1
    return sent
