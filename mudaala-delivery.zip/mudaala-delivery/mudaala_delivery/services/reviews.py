"""Reviews of bodas, tied to confirmed deliveries.

- Timing is measured by the system (pickup to PIN confirmation against the ETA), never typed in.
- "Quality of goods" is the condition on ARRIVAL: the rider does not control the product itself.
- Only PIN-confirmed deliveries can be reviewed, once per reviewer kind (seller, buyer).
- A rider's score is hidden until a few reviews exist, and shrinks toward a neutral prior so one
  review cannot make or break someone."""

import hmac
import sqlite3

from .. import db, security
from ..errors import ApiError
from .common import new_id

# Composite rating 1-5: courtesy 50%, on time 25%, arrived intact 25%.
_RATING_SQL = (
    "(0.5*courtesy + 0.25*(CASE on_time WHEN 1 THEN 5 ELSE 1 END)"
    " + 0.25*(CASE condition_ok WHEN 1 THEN 5 ELSE 1 END))"
)


def score(ctx, boda_id):
    cfg = ctx.config
    row = ctx.db.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(" + _RATING_SQL + "),0) AS total,"
        " COALESCE(AVG(courtesy),0) AS courtesy, COALESCE(AVG(on_time),0) AS on_time,"
        " COALESCE(AVG(condition_ok),0) AS intact FROM reviews WHERE boda_id=?",
        (boda_id,),
    ).fetchone()
    n = row["n"]
    if n < cfg.min_reviews_for_score:
        return {"score": None, "review_count": n, "note": "Not enough reviews yet"}
    shrunk = (cfg.score_prior_weight * cfg.score_prior + row["total"]) / (cfg.score_prior_weight + n)
    return {
        "score": round(shrunk, 2),
        "review_count": n,
        "avg_courtesy": round(row["courtesy"], 2),
        "on_time_rate": round(row["on_time"], 3),
        "arrived_intact_rate": round(row["intact"], 3),
    }


def _insert(ctx, c, d, kind, courtesy, condition_ok, comment, damage_note):
    now, cfg = ctx.now(), ctx.config
    if d["status"] != "DELIVERED" or d["delivered_at"] is None:
        raise ApiError(409, "not_delivered", "Only confirmed deliveries can be reviewed.")
    if now > d["delivered_at"] + cfg.review_window_days * 86400:
        raise ApiError(409, "review_window_closed", "The review window for this delivery has closed.")
    if not condition_ok and not damage_note:
        raise ApiError(422, "damage_note_required", "Describe what was wrong with the item.")
    took = d["delivered_at"] - d["picked_up_at"]
    on_time = 1 if took <= d["eta_minutes"] * 60 else 0
    rid = new_id()
    try:
        c.execute(
            "INSERT INTO reviews(id, delivery_id, boda_id, reviewer_kind, on_time, condition_ok,"
            " courtesy, comment, damage_note, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (rid, d["id"], d["boda_id"], kind, on_time, 1 if condition_ok else 0, courtesy,
             comment, None if condition_ok else damage_note, now),
        )
    except sqlite3.IntegrityError:
        raise ApiError(409, "already_reviewed", "You have already reviewed this delivery.") from None
    return {"id": rid, "on_time": bool(on_time), "minutes_taken": round(took / 60, 1)}


def _load_delivery(c, delivery_id):
    d = c.execute("SELECT * FROM deliveries WHERE id=?", (delivery_id,)).fetchone()
    if d is None:
        raise ApiError(404, "not_found", "Delivery not found.")
    return d


def create_as_seller(ctx, seller, delivery_id, courtesy, condition_ok, comment, damage_note):
    with db.transaction(ctx.db) as c:
        d = _load_delivery(c, delivery_id)
        if d["seller_id"] != seller["id"]:
            raise ApiError(404, "not_found", "Delivery not found.")
        return _insert(ctx, c, d, "seller", courtesy, condition_ok, comment, damage_note)


def create_as_buyer(ctx, delivery_id, token, courtesy, condition_ok, comment, damage_note):
    """Buyers have no account. They prove they were part of the delivery with the secret
    link texted to them after the PIN was confirmed."""
    with db.transaction(ctx.db) as c:
        d = c.execute("SELECT * FROM deliveries WHERE id=?", (delivery_id,)).fetchone()
        stored = d["review_token_hash"] if d else None
        given = security.hash_token(token)
        if not stored or not hmac.compare_digest(stored, given):
            raise ApiError(404, "not_found", "Delivery not found.")  # same answer for every failure
        return _insert(ctx, c, d, "buyer", courtesy, condition_ok, comment, damage_note)


def reply(ctx, boda, review_id, text):
    with db.transaction(ctx.db) as c:
        r = c.execute("SELECT * FROM reviews WHERE id=?", (review_id,)).fetchone()
        if r is None or r["boda_id"] != boda["id"]:
            raise ApiError(404, "not_found", "Review not found.")
        cur = c.execute(
            "UPDATE reviews SET boda_reply=?, replied_at=? WHERE id=? AND boda_reply IS NULL",
            (text, ctx.now(), review_id),
        )
        if cur.rowcount != 1:
            raise ApiError(409, "already_replied", "You have already replied to this review.")
    return {"id": review_id, "boda_reply": text}


def list_for_boda(ctx, boda_id, limit=20, before=None):
    limit = max(1, min(limit, 50))
    params = [boda_id]
    cond = ""
    if before is not None:
        cond = " AND created_at < ?"
        params.append(before)
    params.append(limit)
    rows = ctx.db.execute(
        "SELECT id, reviewer_kind, on_time, condition_ok, courtesy, comment, damage_note,"
        " boda_reply, replied_at, created_at FROM reviews WHERE boda_id=?" + cond +
        " ORDER BY created_at DESC LIMIT ?",
        params,
    ).fetchall()
    return [
        {**dict(r), "on_time": bool(r["on_time"]), "condition_ok": bool(r["condition_ok"])}
        for r in rows
    ]
