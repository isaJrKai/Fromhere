"""Delivery lifecycle.

    SEARCHING -> ASSIGNED -> PICKED_UP -> DELIVERED
        |            |
        |            +--> SEARCHING (rider cancels, re-dispatched)  /  CANCELLED
        +--> NO_BODA  /  CANCELLED                         PICKED_UP -> FAILED (admin only)

Every change runs in one BEGIN IMMEDIATE transaction, so two riders accepting the same job,
or a cancel racing an accept, are serialised by the database and the loser gets a clean 409."""

import hmac
import logging
import math

from .. import db, geo, security
from ..errors import ApiError
from . import bodas, payments, sms
from .common import new_id, record_event, user_phone

log = logging.getLogger("mudaala.deliveries")
ACTIVE = ("ASSIGNED", "PICKED_UP")
OPEN = ("SEARCHING", "ASSIGNED", "PICKED_UP")

_PUBLIC = (
    "id status pickup_lat pickup_lng pickup_landmark dropoff_lat dropoff_lng dropoff_landmark"
    " item_description item_value_ugx distance_km fee_ugx eta_minutes payment_method created_at"
    " assigned_at picked_up_at delivered_at cancelled_at cancel_reason"
).split()


# ---------------------------------------------------------------- pricing

def estimate(ctx, pickup, dropoff):
    cfg = ctx.config
    straight = geo.haversine_km(pickup[0], pickup[1], dropoff[0], dropoff[1])
    distance = round(straight * cfg.road_factor, 2)  # straight line x factor approximates roads
    if distance < 0.1:
        raise ApiError(422, "same_location", "Pickup and drop-off are the same place.")
    if distance > cfg.max_delivery_distance_km:
        raise ApiError(
            422, "too_far", "Deliveries are limited to %d km." % cfg.max_delivery_distance_km
        )
    raw = cfg.base_fee_ugx + cfg.per_km_fee_ugx * distance
    fee = int(math.ceil(raw / cfg.fee_rounding_ugx) * cfg.fee_rounding_ugx)
    eta = int(math.ceil(distance / cfg.avg_speed_kmh * 60)) + cfg.eta_buffer_minutes
    return {"distance_km": distance, "fee_ugx": fee, "eta_minutes": eta}


# ---------------------------------------------------------------- internals

def _load(c, delivery_id):
    d = c.execute("SELECT * FROM deliveries WHERE id=?", (delivery_id,)).fetchone()
    if d is None:
        raise ApiError(404, "not_found", "Delivery not found.")
    return d


def _transition(c, d, to_status, actor_id, now, note=None, **fields):
    """Optimistic, conditional update. Field names are code constants, never user input."""
    sets, params = ["status=?", "version=version+1"], [to_status]
    for k, v in fields.items():
        sets.append(k + "=?")
        params.append(v)
    params += [d["id"], d["status"], d["version"]]
    cur = c.execute(
        "UPDATE deliveries SET " + ", ".join(sets) + " WHERE id=? AND status=? AND version=?", params
    )
    if cur.rowcount != 1:
        raise ApiError(409, "conflict", "This delivery just changed. Refresh and try again.")
    record_event(c, d["id"], d["status"], to_status, actor_id, note, now)


def _withdraw_pending(c, delivery_id, except_boda=None):
    if except_boda:
        c.execute(
            "UPDATE delivery_offers SET status='withdrawn' WHERE delivery_id=? AND status='pending' AND boda_id!=?",
            (delivery_id, except_boda),
        )
    else:
        c.execute(
            "UPDATE delivery_offers SET status='withdrawn' WHERE delivery_id=? AND status='pending'",
            (delivery_id,),
        )


def _dispatch_round(ctx, c, delivery_id):
    """Offer the job to the nearest few eligible bodas. Called inside a transaction."""
    cfg, now = ctx.config, ctx.now()
    d = _load(c, delivery_id)
    if d["status"] != "SEARCHING":
        return
    c.execute(
        "UPDATE delivery_offers SET status='expired' WHERE delivery_id=? AND status='pending' AND expires_at<=?",
        (delivery_id, now),
    )
    round_no = d["dispatch_round"]
    if round_no >= cfg.max_dispatch_rounds:
        _withdraw_pending(c, delivery_id)
        _transition(c, d, "NO_BODA", None, now, "no rider accepted", next_dispatch_at=None)
        sms.queue(
            c, user_phone(c, d["seller_id"]),
            "Mudaala: no rider was available near you for your delivery to %s. Please try again shortly."
            % d["dropoff_landmark"], now,
        )
        return
    # Skip riders who already declined, ignored or dropped this job. Riders whose offer was only
    # withdrawn (someone else accepted first) may be offered again if that rider later drops out.
    already = {
        r["boda_id"]
        for r in c.execute(
            "SELECT boda_id FROM delivery_offers WHERE delivery_id=? AND status!='withdrawn'", (delivery_id,)
        )
    }
    cands = bodas.find_candidates(
        ctx, c, d["pickup_lat"], d["pickup_lng"], d["item_value_ugx"], already
    )[: cfg.offers_per_round]
    for boda_id, _dist in cands:
        c.execute(
            "INSERT INTO delivery_offers(delivery_id, boda_id, round, offered_at, expires_at)"
            " VALUES (?,?,?,?,?)"
            " ON CONFLICT(delivery_id, boda_id) DO UPDATE SET round=excluded.round,"
            " offered_at=excluded.offered_at, expires_at=excluded.expires_at, status='pending'",
            (delivery_id, boda_id, round_no + 1, now, now + cfg.offer_ttl_seconds),
        )
    c.execute(
        "UPDATE deliveries SET dispatch_round=?, next_dispatch_at=?, version=version+1 WHERE id=?",
        (round_no + 1, now + cfg.offer_ttl_seconds, delivery_id),
    )


def _mark_delivered(ctx, c, d, actor_id, note, issue_review_token):
    now = ctx.now()
    token = security.new_opaque_token() if issue_review_token else None
    _transition(
        c, d, "DELIVERED", actor_id, now, note, delivered_at=now,
        review_token_hash=security.hash_token(token) if token else None,
    )
    d2 = _load(c, d["id"])
    payments.create_for_delivery(ctx, c, d2)
    seller_phone = user_phone(c, d["seller_id"])
    sms.queue(c, seller_phone, "Mudaala: your delivery to %s was completed." % d["dropoff_landmark"], now)
    if token:
        link = "%s/r/%s?t=%s" % (ctx.config.public_base_url, d["id"], token)
        sms.queue(
            c, d["buyer_phone"],
            "Mudaala: thanks for receiving your item. Rate your rider (1 minute): " + link, now,
        )


# ---------------------------------------------------------------- seller actions

def create(ctx, seller, data, idempotency_key=None):
    """Returns (delivery, created). A repeated idempotency key returns the original delivery."""
    cfg = ctx.config
    quote = estimate(
        ctx, (data["pickup_lat"], data["pickup_lng"]), (data["dropoff_lat"], data["dropoff_lng"])
    )
    buyer_phone = _norm_phone(ctx, data["buyer_phone"])
    delivery_id, pin, now = new_id(), security.new_pin(), ctx.now()
    with db.transaction(ctx.db) as c:
        if idempotency_key:
            old = c.execute(
                "SELECT * FROM deliveries WHERE seller_id=? AND idempotency_key=?",
                (seller["id"], idempotency_key),
            ).fetchone()
            if old:
                return _present(ctx, c, old, seller), False
        open_count = c.execute(
            "SELECT COUNT(*) FROM deliveries WHERE seller_id=? AND status IN ('SEARCHING','ASSIGNED','PICKED_UP')",
            (seller["id"],),
        ).fetchone()[0]
        if open_count >= cfg.max_open_deliveries_per_seller:
            raise ApiError(429, "too_many_open", "You have too many deliveries in progress.")
        row = {
            "id": delivery_id, "seller_id": seller["id"], "status": "SEARCHING",
            "pickup_lat": data["pickup_lat"], "pickup_lng": data["pickup_lng"],
            "pickup_landmark": data["pickup_landmark"],
            "dropoff_lat": data["dropoff_lat"], "dropoff_lng": data["dropoff_lng"],
            "dropoff_landmark": data["dropoff_landmark"],
            "buyer_name": data["buyer_name"], "buyer_phone": buyer_phone,
            "item_description": data["item_description"], "item_value_ugx": data["item_value_ugx"],
            "distance_km": quote["distance_km"], "fee_ugx": quote["fee_ugx"],
            "eta_minutes": quote["eta_minutes"], "payment_method": data["payment_method"],
            "pin_hash": security.hash_pin(cfg.pin_secret, delivery_id, pin),
            "idempotency_key": idempotency_key, "created_at": now,
        }
        # Column names come from the literal dict above, never from user input.
        c.execute(
            "INSERT INTO deliveries(" + ", ".join(row) + ") VALUES (" + ",".join("?" * len(row)) + ")",
            list(row.values()),
        )
        record_event(c, delivery_id, None, "SEARCHING", seller["id"], None, now)
        sms.queue(
            c, buyer_phone,
            "Mudaala: %s is sending you an item. Your delivery code is %s. Give it to the rider ONLY"
            " after you have received and checked your item." % (seller["name"], pin), now,
        )
        _dispatch_round(ctx, c, delivery_id)
        return _present(ctx, c, _load(c, delivery_id), seller), True


def _norm_phone(ctx, raw):
    from ..validation import normalize_phone

    return normalize_phone(raw, ctx.config.default_country_code)


# ---------------------------------------------------------------- boda actions

def accept(ctx, boda, delivery_id):
    now, cfg = ctx.now(), ctx.config
    with db.transaction(ctx.db) as c:
        d = _load(c, delivery_id)
        profile = bodas.get_profile(c, boda["id"])
        if profile is None or profile["status"] != "approved":
            raise ApiError(403, "not_approved", "Your account has not been approved yet.")
        offer = c.execute(
            "SELECT * FROM delivery_offers WHERE delivery_id=? AND boda_id=?", (delivery_id, boda["id"])
        ).fetchone()
        if offer is None:
            raise ApiError(404, "not_found", "Delivery not found.")
        if d["status"] != "SEARCHING" or offer["status"] != "pending" or offer["expires_at"] <= now:
            raise ApiError(409, "no_longer_available", "This job is no longer available.")
        if c.execute(
            "SELECT 1 FROM deliveries WHERE boda_id=? AND status IN ('ASSIGNED','PICKED_UP')", (boda["id"],)
        ).fetchone():
            raise ApiError(409, "already_busy", "Finish your current delivery first.")
        cap = bodas.value_cap(cfg, bodas.completed_count(c, boda["id"]))
        if d["item_value_ugx"] > cap:
            raise ApiError(403, "value_over_cap", "This item is worth more than you can carry yet.")
        _transition(c, d, "ASSIGNED", boda["id"], now, boda_id=boda["id"], assigned_at=now, next_dispatch_at=None)
        c.execute(
            "UPDATE delivery_offers SET status='accepted' WHERE delivery_id=? AND boda_id=?",
            (delivery_id, boda["id"]),
        )
        _withdraw_pending(c, delivery_id, except_boda=boda["id"])
        plate = profile["plate_number"]
        sms.queue(
            c, user_phone(c, d["seller_id"]),
            "Mudaala: rider %s (%s, %s) accepted your delivery to %s." % (boda["name"], plate, boda["phone"], d["dropoff_landmark"]),
            now,
        )
        sms.queue(
            c, d["buyer_phone"],
            "Mudaala: rider %s (plate %s) is collecting your item and will bring it to %s."
            % (boda["name"], plate, d["dropoff_landmark"]), now,
        )
        return _present(ctx, c, _load(c, delivery_id), boda)


def decline(ctx, boda, delivery_id):
    now = ctx.now()
    with db.transaction(ctx.db) as c:
        cur = c.execute(
            "UPDATE delivery_offers SET status='declined' WHERE delivery_id=? AND boda_id=? AND status='pending'",
            (delivery_id, boda["id"]),
        )
        if cur.rowcount != 1:
            raise ApiError(404, "not_found", "Offer not found.")
        left = c.execute(
            "SELECT COUNT(*) FROM delivery_offers WHERE delivery_id=? AND status='pending' AND expires_at>?",
            (delivery_id, now),
        ).fetchone()[0]
        if left == 0:
            _dispatch_round(ctx, c, delivery_id)  # everyone said no: try the next riders now
    return {"ok": True}


def pickup(ctx, boda, delivery_id):
    now = ctx.now()
    with db.transaction(ctx.db) as c:
        d = _load(c, delivery_id)
        if d["boda_id"] != boda["id"]:
            raise ApiError(404, "not_found", "Delivery not found.")
        if d["status"] != "ASSIGNED":
            raise ApiError(409, "invalid_state", "This delivery cannot be picked up right now.")
        _transition(c, d, "PICKED_UP", boda["id"], now, picked_up_at=now)
        return _present(ctx, c, _load(c, delivery_id), boda)


def confirm(ctx, boda, delivery_id, pin):
    """Complete the delivery with the code the buyer reads out. Wrong codes are counted and
    persisted (so retries cannot be unlimited) before the error is raised."""
    cfg, now = ctx.config, ctx.now()
    bad_attempt = None
    result = None
    with db.transaction(ctx.db) as c:
        d = _load(c, delivery_id)
        if d["boda_id"] != boda["id"]:
            raise ApiError(404, "not_found", "Delivery not found.")
        if d["status"] != "PICKED_UP":
            raise ApiError(409, "invalid_state", "Pick up the item before confirming delivery.")
        if d["pin_attempts"] >= cfg.pin_max_attempts:
            raise ApiError(423, "pin_locked", "Too many wrong codes. Contact Mudaala support.")
        expected = security.hash_pin(cfg.pin_secret, d["id"], pin)
        if hmac.compare_digest(expected, d["pin_hash"]):
            _mark_delivered(ctx, c, d, boda["id"], "pin confirmed", issue_review_token=True)
            result = _present(ctx, c, _load(c, delivery_id), boda)
        else:
            attempts = d["pin_attempts"] + 1
            c.execute(
                "UPDATE deliveries SET pin_attempts=?, version=version+1 WHERE id=?", (attempts, d["id"])
            )
            record_event(c, d["id"], d["status"], d["status"], boda["id"], "wrong pin", now)
            if attempts >= cfg.pin_max_attempts:
                sms.queue(
                    c, user_phone(c, d["seller_id"]),
                    "Mudaala: delivery to %s is locked after wrong codes. Contact support." % d["dropoff_landmark"],
                    now,
                )
            bad_attempt = cfg.pin_max_attempts - attempts
    if bad_attempt is not None:
        raise ApiError(400, "wrong_pin", "That code is not correct.", {"attempts_remaining": bad_attempt})
    _after_delivered(ctx, delivery_id)
    return result


def _after_delivered(ctx, delivery_id):
    try:
        payments.start(ctx, delivery_id)
    except Exception:  # the worker retries; never fail a completed delivery over a charge
        log.exception("payment start failed delivery=%s", delivery_id)


# ---------------------------------------------------------------- cancel / admin

def cancel(ctx, actor, delivery_id, reason=None):
    now = ctx.now()
    with db.transaction(ctx.db) as c:
        d = _load(c, delivery_id)
        role = actor["role"]
        if role == "seller" and d["seller_id"] == actor["id"]:
            if d["status"] not in ("SEARCHING", "ASSIGNED"):
                raise ApiError(409, "cannot_cancel", "This delivery can no longer be cancelled. Contact support.")
            boda_id = d["boda_id"]
            _transition(c, d, "CANCELLED", actor["id"], now, reason, cancelled_at=now,
                        cancel_reason=reason, next_dispatch_at=None)
            _withdraw_pending(c, delivery_id)
            if boda_id:
                sms.queue(c, user_phone(c, boda_id),
                          "Mudaala: the delivery to %s was cancelled by the seller." % d["dropoff_landmark"], now)
        elif role == "boda" and d["boda_id"] == actor["id"]:
            if d["status"] != "ASSIGNED":
                raise ApiError(409, "cannot_cancel", "You can only drop a job before pickup. Contact support.")
            _transition(c, d, "SEARCHING", actor["id"], now, "rider cancelled: %s" % (reason or ""),
                        boda_id=None, assigned_at=None, dispatch_round=0, next_dispatch_at=None)
            c.execute(
                "UPDATE delivery_offers SET status='declined' WHERE delivery_id=? AND boda_id=?",
                (delivery_id, actor["id"]),
            )
            sms.queue(c, user_phone(c, d["seller_id"]),
                      "Mudaala: your rider dropped the delivery. We are finding another rider.", now)
            _dispatch_round(ctx, c, delivery_id)  # the dropped rider is excluded: they already have an offer row
        else:
            raise ApiError(404, "not_found", "Delivery not found.")
        out = _present(ctx, c, _load(c, delivery_id), actor)
    return out


def resolve(ctx, admin, delivery_id, outcome, note):
    """Admin settles a stuck delivery (for example, PIN locked or rider unreachable)."""
    if outcome not in ("DELIVERED", "FAILED", "CANCELLED"):
        raise ApiError(422, "invalid_outcome", "Outcome must be DELIVERED, FAILED or CANCELLED.")
    now = ctx.now()
    with db.transaction(ctx.db) as c:
        d = _load(c, delivery_id)
        if d["status"] not in ACTIVE:
            raise ApiError(409, "invalid_state", "Only assigned or picked-up deliveries can be resolved.")
        if outcome == "DELIVERED":
            if d["picked_up_at"] is None:
                raise ApiError(409, "invalid_state", "The item was never picked up.")
            _mark_delivered(ctx, c, d, admin["id"], "admin: " + note, issue_review_token=False)
        else:
            _transition(c, d, outcome, admin["id"], now, "admin: " + note,
                        cancelled_at=now, cancel_reason=note)
        out = _present(ctx, c, _load(c, delivery_id), admin)
    if outcome == "DELIVERED":
        _after_delivered(ctx, delivery_id)
    return out


def process_due(ctx, limit=100) -> int:
    """Worker: advance every SEARCHING delivery whose offers have run out."""
    now, done = ctx.now(), 0
    ids = [
        r["id"]
        for r in ctx.db.execute(
            "SELECT id FROM deliveries WHERE status='SEARCHING' AND next_dispatch_at IS NOT NULL"
            " AND next_dispatch_at<=? ORDER BY next_dispatch_at LIMIT ?",
            (now, limit),
        )
    ]
    for delivery_id in ids:
        try:
            with db.transaction(ctx.db) as c:
                d = _load(c, delivery_id)
                if d["status"] == "SEARCHING" and d["next_dispatch_at"] is not None and d["next_dispatch_at"] <= now:
                    _dispatch_round(ctx, c, delivery_id)
                    done += 1
        except Exception:
            log.exception("dispatch failed delivery=%s", delivery_id)
    return done


# ---------------------------------------------------------------- reads

def _present(ctx, c, d, viewer):
    """Shape a delivery for one viewer. PIN data and internal fields are never included, and a
    rider sees the buyer's name and number only while the job is actually theirs."""
    role = viewer["role"]
    out = {k: d[k] for k in _PUBLIC}
    out["id"] = d["id"]
    out["created_at"] = d["created_at"]
    mine = d["boda_id"] == viewer["id"]
    if role in ("seller", "admin") or (role == "boda" and mine and d["status"] in ACTIVE):
        out["buyer_name"] = d["buyer_name"]
        out["buyer_phone"] = d["buyer_phone"]
    if d["boda_id"] and (role in ("seller", "admin") or mine):
        row = c.execute(
            "SELECT u.name, u.phone, bp.plate_number FROM users u JOIN boda_profiles bp ON bp.user_id=u.id WHERE u.id=?",
            (d["boda_id"],),
        ).fetchone()
        if row:
            out["boda"] = {"id": d["boda_id"], "name": row["name"], "plate_number": row["plate_number"]}
            if role != "boda" and d["status"] in ACTIVE:
                out["boda"]["phone"] = row["phone"]
    pay = payments.get_for_delivery(c, d["id"])
    if pay:
        out["payment"] = (
            {"status": pay["status"], "fee_ugx": pay["fee_ugx"]}
            if role != "boda"
            else {"status": pay["status"], "earning_ugx": pay["boda_earning_ugx"]}
        )
    if role == "seller" or role == "admin":
        out["seller_id"] = d["seller_id"]
    return out


def get_for_user(ctx, user, delivery_id):
    c = ctx.db
    d = _load(c, delivery_id)
    role = user["role"]
    if role == "seller" and d["seller_id"] != user["id"]:
        raise ApiError(404, "not_found", "Delivery not found.")
    if role == "boda" and d["boda_id"] != user["id"]:
        offered = c.execute(
            "SELECT 1 FROM delivery_offers WHERE delivery_id=? AND boda_id=? AND status='pending' AND expires_at>?",
            (delivery_id, user["id"], ctx.now()),
        ).fetchone()
        if not offered:
            raise ApiError(404, "not_found", "Delivery not found.")
    return _present(ctx, c, d, user)


def list_for_seller(ctx, seller, status=None, limit=20, before=None):
    limit = max(1, min(limit, 50))
    sql, params = "SELECT * FROM deliveries WHERE seller_id=?", [seller["id"]]
    if status:
        sql += " AND status=?"
        params.append(status)
    if before is not None:
        sql += " AND created_at<?"
        params.append(before)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    return [_present(ctx, ctx.db, r, seller) for r in ctx.db.execute(sql, params)]


def list_all(ctx, admin, status=None, limit=50):
    limit = max(1, min(limit, 100))
    if status:
        rows = ctx.db.execute(
            "SELECT * FROM deliveries WHERE status=? ORDER BY created_at DESC LIMIT ?", (status, limit)
        )
    else:
        rows = ctx.db.execute("SELECT * FROM deliveries ORDER BY created_at DESC LIMIT ?", (limit,))
    return [_present(ctx, ctx.db, r, admin) for r in rows]


def offers_for_boda(ctx, boda):
    """Jobs currently offered to this rider. Buyer details are hidden until they accept."""
    cfg, now = ctx.config, ctx.now()
    profile = bodas.get_profile(ctx.db, boda["id"])
    rows = ctx.db.execute(
        "SELECT d.*, o.expires_at AS offer_expires_at FROM delivery_offers o"
        " JOIN deliveries d ON d.id=o.delivery_id"
        " WHERE o.boda_id=? AND o.status='pending' AND o.expires_at>? AND d.status='SEARCHING'"
        " ORDER BY o.offered_at",
        (boda["id"], now),
    ).fetchall()
    out = []
    for d in rows:
        item = _present(ctx, ctx.db, d, boda)
        item["offer_expires_at"] = d["offer_expires_at"]
        item["earning_ugx"] = d["fee_ugx"] - int(round(d["fee_ugx"] * cfg.commission_rate))
        if profile and profile["last_lat"] is not None:
            item["distance_to_pickup_km"] = round(
                geo.haversine_km(profile["last_lat"], profile["last_lng"], d["pickup_lat"], d["pickup_lng"]), 2
            )
        out.append(item)
    return out


def active_for_boda(ctx, boda):
    d = ctx.db.execute(
        "SELECT * FROM deliveries WHERE boda_id=? AND status IN ('ASSIGNED','PICKED_UP') LIMIT 1", (boda["id"],)
    ).fetchone()
    return _present(ctx, ctx.db, d, boda) if d else None


def history_for_boda(ctx, boda, limit=20):
    limit = max(1, min(limit, 50))
    rows = ctx.db.execute(
        "SELECT * FROM deliveries WHERE boda_id=? AND status IN ('DELIVERED','FAILED') ORDER BY created_at DESC LIMIT ?",
        (boda["id"], limit),
    ).fetchall()
    return [_present(ctx, ctx.db, r, boda) for r in rows]
