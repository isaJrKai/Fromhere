CREATE TABLE users (
    id            TEXT PRIMARY KEY,
    phone         TEXT NOT NULL UNIQUE,
    name          TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('seller', 'boda', 'admin')),
    is_active     INTEGER NOT NULL DEFAULT 1,
    created_at    INTEGER NOT NULL
);

CREATE TABLE refresh_tokens (
    id         TEXT PRIMARY KEY,
    user_id    TEXT NOT NULL REFERENCES users(id),
    token_hash TEXT NOT NULL UNIQUE,
    expires_at INTEGER NOT NULL,
    revoked    INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);
CREATE INDEX idx_refresh_user ON refresh_tokens(user_id);

CREATE TABLE boda_profiles (
    user_id         TEXT PRIMARY KEY REFERENCES users(id),
    national_id     TEXT NOT NULL,
    plate_number    TEXT NOT NULL UNIQUE,
    guarantor_name  TEXT NOT NULL,
    guarantor_phone TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'suspended')),
    is_available    INTEGER NOT NULL DEFAULT 0,
    last_lat        REAL,
    last_lng        REAL,
    last_ping_at    INTEGER,
    approved_by     TEXT REFERENCES users(id),
    approved_at     INTEGER,
    created_at      INTEGER NOT NULL
);
CREATE INDEX idx_boda_match ON boda_profiles(status, is_available, last_ping_at);

CREATE TABLE deliveries (
    id               TEXT PRIMARY KEY,
    seller_id        TEXT NOT NULL REFERENCES users(id),
    boda_id          TEXT REFERENCES users(id),
    status           TEXT NOT NULL CHECK (status IN
                        ('SEARCHING', 'ASSIGNED', 'PICKED_UP', 'DELIVERED', 'CANCELLED', 'NO_BODA', 'FAILED')),
    pickup_lat       REAL NOT NULL,
    pickup_lng       REAL NOT NULL,
    pickup_landmark  TEXT NOT NULL,
    dropoff_lat      REAL NOT NULL,
    dropoff_lng      REAL NOT NULL,
    dropoff_landmark TEXT NOT NULL,
    buyer_name       TEXT NOT NULL,
    buyer_phone      TEXT NOT NULL,
    item_description TEXT NOT NULL,
    item_value_ugx   INTEGER NOT NULL CHECK (item_value_ugx >= 0),
    distance_km      REAL NOT NULL,
    fee_ugx          INTEGER NOT NULL,
    eta_minutes      INTEGER NOT NULL,
    payment_method   TEXT NOT NULL CHECK (payment_method IN ('cash', 'mobile_money')),
    pin_hash         TEXT NOT NULL,
    pin_attempts     INTEGER NOT NULL DEFAULT 0,
    review_token_hash TEXT,
    idempotency_key  TEXT,
    dispatch_round   INTEGER NOT NULL DEFAULT 0,
    next_dispatch_at INTEGER,
    cancel_reason    TEXT,
    created_at       INTEGER NOT NULL,
    assigned_at      INTEGER,
    picked_up_at     INTEGER,
    delivered_at     INTEGER,
    cancelled_at     INTEGER,
    version          INTEGER NOT NULL DEFAULT 0,
    UNIQUE (seller_id, idempotency_key)
);
CREATE INDEX idx_deliveries_seller ON deliveries(seller_id, created_at);
CREATE INDEX idx_deliveries_boda ON deliveries(boda_id, status);
CREATE INDEX idx_deliveries_due ON deliveries(status, next_dispatch_at);
CREATE INDEX idx_deliveries_review_token ON deliveries(review_token_hash);

CREATE TABLE delivery_offers (
    delivery_id TEXT NOT NULL REFERENCES deliveries(id),
    boda_id     TEXT NOT NULL REFERENCES users(id),
    round       INTEGER NOT NULL,
    offered_at  INTEGER NOT NULL,
    expires_at  INTEGER NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending', 'accepted', 'declined', 'expired', 'withdrawn')),
    PRIMARY KEY (delivery_id, boda_id)
);
CREATE INDEX idx_offers_boda ON delivery_offers(boda_id, status);

-- Append-only audit trail of every status change.
CREATE TABLE delivery_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    delivery_id TEXT NOT NULL REFERENCES deliveries(id),
    from_status TEXT,
    to_status   TEXT NOT NULL,
    actor_id    TEXT,
    note        TEXT,
    created_at  INTEGER NOT NULL
);
CREATE INDEX idx_events_delivery ON delivery_events(delivery_id);

CREATE TABLE payments (
    id               TEXT PRIMARY KEY,
    delivery_id      TEXT NOT NULL UNIQUE REFERENCES deliveries(id),
    method           TEXT NOT NULL,
    fee_ugx          INTEGER NOT NULL,
    commission_ugx   INTEGER NOT NULL,
    boda_earning_ugx INTEGER NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending', 'processing', 'paid', 'failed')),
    provider_ref     TEXT,
    attempts         INTEGER NOT NULL DEFAULT 0,
    created_at       INTEGER NOT NULL,
    updated_at       INTEGER NOT NULL
);
CREATE INDEX idx_payments_ref ON payments(provider_ref);

CREATE TABLE reviews (
    id            TEXT PRIMARY KEY,
    delivery_id   TEXT NOT NULL REFERENCES deliveries(id),
    boda_id       TEXT NOT NULL REFERENCES users(id),
    reviewer_kind TEXT NOT NULL CHECK (reviewer_kind IN ('seller', 'buyer')),
    on_time       INTEGER NOT NULL CHECK (on_time IN (0, 1)),
    condition_ok  INTEGER NOT NULL CHECK (condition_ok IN (0, 1)),
    courtesy      INTEGER NOT NULL CHECK (courtesy BETWEEN 1 AND 5),
    comment       TEXT,
    damage_note   TEXT,
    boda_reply    TEXT,
    replied_at    INTEGER,
    created_at    INTEGER NOT NULL,
    UNIQUE (delivery_id, reviewer_kind)
);
CREATE INDEX idx_reviews_boda ON reviews(boda_id, created_at);

-- Transactional outbox: messages are written in the same transaction as the change that
-- caused them, and a worker sends them afterwards.
CREATE TABLE sms_outbox (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    to_phone   TEXT NOT NULL,
    body       TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed')),
    attempts   INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    sent_at    INTEGER
);
CREATE INDEX idx_outbox_status ON sms_outbox(status, id);

CREATE TABLE webhook_events (
    event_id    TEXT PRIMARY KEY,
    received_at INTEGER NOT NULL
);
