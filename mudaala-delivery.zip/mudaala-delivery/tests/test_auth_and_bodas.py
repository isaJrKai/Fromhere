import json

from mudaala_delivery.services import bodas as bodas_service
from mudaala_delivery.config import Config

from conftest import NEAR1, PW


# ------------------------------------------------------------------ auth

def test_register_login_and_phone_formats_are_one_account(w):
    w.user("seller", "0701234567")
    r = w.client.post("/v1/auth/register", json={"phone": "+256 701 234 567", "name": "Dup", "password": PW, "role": "seller"})
    assert r.status_code == 409 and r.json["error"]["code"] == "phone_taken"
    r = w.client.post("/v1/auth/login", json={"phone": "256701234567", "password": PW})
    assert r.status_code == 200 and r.json["token_type"] == "Bearer"


def test_wrong_password_and_unknown_phone_look_identical(w):
    w.user("seller", "0701234567")
    a = w.client.post("/v1/auth/login", json={"phone": "0701234567", "password": "wrong-password"})
    b = w.client.post("/v1/auth/login", json={"phone": "0709999999", "password": "wrong-password"})
    assert a.status_code == b.status_code == 401 and a.json == b.json


def test_registration_validation(w):
    bad = [
        {"phone": "0701234567", "name": "A", "password": PW, "role": "seller"},            # short name
        {"phone": "0701234567", "name": "Ann", "password": "short", "role": "seller"},      # short password
        {"phone": "0701234567", "name": "Ann", "password": PW, "role": "admin"},            # no self-service admin
        {"phone": "abc", "name": "Ann", "password": PW, "role": "seller"},                  # bad phone
        {"phone": "0701234567", "name": "Ann", "password": PW, "role": "seller", "is_admin": True},  # unknown field
    ]
    for payload in bad:
        r = w.client.post("/v1/auth/register", json=payload)
        assert r.status_code == 422, payload


def test_token_checks(w):
    s = w.seller()
    assert w.get("/v1/deliveries").status_code == 401
    assert w.client.get("/v1/deliveries", headers={"Authorization": "Bearer nonsense"}).status_code == 401
    tampered = s.token[:-3] + ("aaa" if not s.token.endswith("aaa") else "bbb")
    assert w.client.get("/v1/deliveries", headers={"Authorization": "Bearer " + tampered}).status_code == 401
    assert w.get("/v1/deliveries", s).status_code == 200
    w.clock.advance(w.cfg.access_token_minutes * 60 + 1)
    r = w.get("/v1/deliveries", s)
    assert r.status_code == 401 and "expired" in r.json["error"]["message"].lower()


def test_refresh_rotation_and_reuse_detection(w):
    s = w.seller()
    r1 = w.client.post("/v1/auth/refresh", json={"refresh_token": s.refresh})
    assert r1.status_code == 200
    new_refresh = r1.json["refresh_token"]
    # Replaying the old token is treated as theft: everything for this user is revoked.
    assert w.client.post("/v1/auth/refresh", json={"refresh_token": s.refresh}).status_code == 401
    assert w.client.post("/v1/auth/refresh", json={"refresh_token": new_refresh}).status_code == 401


def test_logout_revokes_refresh_token(w):
    s = w.seller()
    assert w.client.post("/v1/auth/logout", json={"refresh_token": s.refresh}).status_code == 200
    assert w.client.post("/v1/auth/refresh", json={"refresh_token": s.refresh}).status_code == 401


def test_deactivated_user_is_cut_off_immediately(w):
    s = w.seller()
    from mudaala_delivery.services import users
    users.deactivate(w.ctx, s.id)
    assert w.get("/v1/deliveries", s).status_code == 401
    assert w.client.post("/v1/auth/login", json={"phone": "0701000001", "password": PW}).status_code == 401


def test_login_is_rate_limited(make_world):
    w = make_world(rate_limit_auth_per_minute=5)
    w.seller()
    w.clock.advance(61)  # let the logins used during setup age out of the one-minute window
    codes = [w.client.post("/v1/auth/login", json={"phone": "0701000001", "password": "bad-password"}).status_code for _ in range(7)]
    assert codes == [401] * 5 + [429] * 2
    w.clock.advance(61)
    assert w.client.post("/v1/auth/login", json={"phone": "0701000001", "password": PW}).status_code == 200


def test_role_guards(w):
    s, b = w.seller(), w.boda()
    assert w.post("/v1/deliveries", b, w.payload()).status_code == 403
    assert w.get("/v1/bodas/me/offers", s).status_code == 403
    assert w.get("/v1/admin/bodas", s).status_code == 403
    assert w.post("/v1/admin/bodas/%s/approve" % b.id, b).status_code == 403


def test_bad_bodies_and_oversize(w):
    s = w.seller()
    assert w.client.post("/v1/deliveries", data="not json", headers=s.h).status_code == 400
    assert w.client.post("/v1/deliveries", data=json.dumps([1, 2]), headers={**s.h, "Content-Type": "application/json"}).status_code == 400
    big = w.client.post("/v1/deliveries", data="x" * 70_000, headers={**s.h, "Content-Type": "application/json"})
    assert big.status_code == 413 and big.json["error"]["code"] == "too_large"


def test_unexpected_error_hides_internals(w, monkeypatch):
    s = w.seller()
    from mudaala_delivery.services import deliveries
    monkeypatch.setattr(deliveries, "list_for_seller", lambda *a, **k: 1 / 0)
    r = w.get("/v1/deliveries", s)
    assert r.status_code == 500 and "ZeroDivision" not in r.get_data(as_text=True)
    assert r.json["error"]["code"] == "internal_error"


# ------------------------------------------------------------------ bodas

def test_unapproved_boda_cannot_work(w):
    b = w.boda(approve=False)
    assert w.req("PUT", "/v1/bodas/me/availability", b, {"available": True}).status_code == 403
    assert w.post("/v1/bodas/me/location", b, {"lat": 0.3, "lng": 32.5}).status_code == 403
    prof = w.get("/v1/bodas/me", b).json
    assert prof["status"] == "pending"


def test_apply_rules(w):
    b = w.boda(approve=False)
    again = w.post("/v1/bodas/me/profile", b, {"national_id": "CM90001234567X", "plate_number": "UBB 111Z", "guarantor_name": "Gee Guarantor", "guarantor_phone": "0788000111"})
    assert again.status_code == 409 and again.json["error"]["code"] == "already_applied"
    other = w.user("boda", "0772999000")
    dup_plate = w.post("/v1/bodas/me/profile", other, {"national_id": "CM90009999999X", "plate_number": "uba 001x", "guarantor_name": "Gee", "guarantor_phone": "0788000222"})
    assert dup_plate.status_code == 409 and dup_plate.json["error"]["code"] == "plate_taken"
    self_guarantor = w.post("/v1/bodas/me/profile", other, {"national_id": "CM90009999999X", "plate_number": "UBC 222Q", "guarantor_name": "Me", "guarantor_phone": "0772999000"})
    assert self_guarantor.status_code == 422
    seller = w.seller()
    assert w.post("/v1/bodas/me/profile", seller, {}).status_code == 403


def test_profile_masks_national_id_and_shows_cap(w):
    b = w.boda()
    p = w.get("/v1/bodas/me", b).json
    assert "*" in p["national_id"] and p["national_id"].startswith("CM")
    assert p["value_cap_ugx"] == w.cfg.new_boda_value_cap_ugx
    assert p["rating"]["score"] is None


def test_value_cap_ladder():
    cfg = Config()
    assert bodas_service.value_cap(cfg, 0) == 200_000
    assert bodas_service.value_cap(cfg, 9) == 200_000
    assert bodas_service.value_cap(cfg, 10) == 300_000
    assert bodas_service.value_cap(cfg, 35) == 500_000
    assert bodas_service.value_cap(cfg, 10_000) == cfg.max_value_cap_ugx


def test_suspending_takes_boda_off_the_map(w):
    s, b = w.seller(), w.boda()
    assert w.post("/v1/admin/bodas/%s/suspend" % b.id, w.admin).status_code == 200
    w.create(s)
    assert w.offers(b) == []
    assert w.req("PUT", "/v1/bodas/me/availability", b, {"available": True}).status_code == 403


def test_admin_lists_pending_bodas(w):
    w.boda(approve=False)
    rows = w.get("/v1/admin/bodas?status=pending", w.admin).json["bodas"]
    assert len(rows) == 1 and rows[0]["plate_number"].startswith("UBA")
    assert w.get("/v1/admin/bodas?status=nonsense", w.admin).status_code == 422


def test_boda_location_validation(w):
    b = w.boda()
    for bad in ({"lat": 91, "lng": 0}, {"lat": 0, "lng": 181}, {"lat": "x", "lng": 0}, {"lat": 0}):
        assert w.post("/v1/bodas/me/location", b, bad).status_code == 422
    raw = '{"lat": NaN, "lng": 1}'
    r = w.client.post("/v1/bodas/me/location", data=raw, headers={**b.h, "Content-Type": "application/json"})
    assert r.status_code == 422
