import json
import re
from dataclasses import dataclass

import pytest

from mudaala_delivery import db, worker
from mudaala_delivery.api import create_app
from mudaala_delivery.config import Config
from mudaala_delivery.ctx import Context
from mudaala_delivery.security import sign_webhook
from mudaala_delivery.services import users

PW = "correct-horse-1"
WEBHOOK_SECRET = "w" * 32

# Kampala-ish points. Pickup to dropoff is about 3.8 km straight, so 5.3 km by road.
PICKUP = (0.3476, 32.5825)
DROPOFF = (0.3136, 32.5811)
# Distances from PICKUP: NEAR1 0.07 km, NEAR2 0.39, NEAR3 0.40, NEAR4 0.97, FAR 17 km.
NEAR1, NEAR2, NEAR3, NEAR4, FAR = (
    (0.3480, 32.5830), (0.3500, 32.5850), (0.3450, 32.5800), (0.3520, 32.5900), (0.45, 32.70),
)


class Clock:
    def __init__(self):
        self.t = 1_800_000_000

    def __call__(self):
        return self.t

    def advance(self, seconds):
        self.t += seconds


class FakeSms:
    def __init__(self):
        self.messages = []
        self.fail = False

    def send(self, phone, body):
        if self.fail:
            raise RuntimeError("gateway down")
        self.messages.append((phone, body))

    def to(self, phone):
        return [b for p, b in self.messages if p == phone]


class FakeProvider:
    def __init__(self):
        self.charges = []
        self.fail = False

    def charge(self, payment_id, phone, amount_ugx):
        if self.fail:
            raise RuntimeError("provider down")
        self.charges.append((payment_id, phone, amount_ugx))
        return "ref-" + payment_id


@dataclass
class U:
    id: str
    phone: str
    token: str
    refresh: str
    lat: float = None
    lng: float = None

    @property
    def h(self):
        return {"Authorization": "Bearer " + self.token}


class World:
    def __init__(self, tmp_path, **overrides):
        self.clock, self.sms, self.provider = Clock(), FakeSms(), FakeProvider()
        base = dict(
            database_path=str(tmp_path / "t.db"), jwt_secret="j" * 32, pin_secret="p" * 32,
            webhook_secret=WEBHOOK_SECRET, rate_limit_auth_per_minute=1000,
            # Tests jump the fake clock by hours and days; keep logins valid unless a test is about expiry.
            access_token_minutes=100_000,
        )
        base.update(overrides)
        self.cfg = Config(**base)
        self.ctx = Context(self.cfg, clock=self.clock, sms_gateway=self.sms, payment_provider=self.provider)
        db.migrate(self.ctx.db)
        self.app = create_app(ctx=self.ctx)
        self.client = self.app.test_client()
        self.bodas, self._n = [], 0
        users.create_admin(self.ctx, "0700999999", "Admin", "admin-password-123")
        t = self.client.post("/v1/auth/login", json={"phone": "0700999999", "password": "admin-password-123"}).json
        self.admin = U("", "+256700999999", t["access_token"], t["refresh_token"])

    # ---- requests
    def req(self, method, path, user=None, json_body=None, headers=None, **kw):
        h = dict(headers or {})
        if user is not None:
            h.update(user.h)
        return self.client.open(path, method=method, json=json_body, headers=h, **kw)

    def post(self, path, user=None, body=None, **kw):
        return self.req("POST", path, user, body if body is not None else {}, **kw)

    def get(self, path, user=None, **kw):
        return self.req("GET", path, user, **kw)

    # ---- people
    def user(self, role, phone):
        r = self.client.post("/v1/auth/register", json={"phone": phone, "name": role.title() + " " + phone[-4:], "password": PW, "role": role})
        assert r.status_code == 201, r.json
        t = self.client.post("/v1/auth/login", json={"phone": phone, "password": PW}).json
        return U(r.json["id"], r.json["phone"], t["access_token"], t["refresh_token"])

    def seller(self, phone="0701000001"):
        return self.user("seller", phone)

    def boda(self, loc=NEAR1, approve=True, available=True, phone=None):
        self._n += 1
        phone = phone or "07720%05d" % self._n
        u = self.user("boda", phone)
        r = self.post("/v1/bodas/me/profile", u, {
            "national_id": "CM9000%08d" % self._n, "plate_number": "UBA %03dX" % self._n,
            "guarantor_name": "Guarantor %d" % self._n, "guarantor_phone": "07990%05d" % self._n,
        })
        assert r.status_code == 201, r.json
        u.lat, u.lng = loc
        if approve:
            assert self.post("/v1/admin/bodas/%s/approve" % u.id, self.admin).status_code == 200
            self.ping(u)
            if available:
                assert self.req("PUT", "/v1/bodas/me/availability", u, {"available": True}).status_code == 200
            self.bodas.append(u)
        return u

    def ping(self, u, loc=None):
        if loc:
            u.lat, u.lng = loc
        r = self.post("/v1/bodas/me/location", u, {"lat": u.lat, "lng": u.lng})
        assert r.status_code == 200, r.json

    def repong(self):
        for b in self.bodas:
            self.ping(b)

    # ---- deliveries
    def payload(self, **o):
        d = dict(
            pickup_lat=PICKUP[0], pickup_lng=PICKUP[1], pickup_landmark="Owino Market gate 2",
            dropoff_lat=DROPOFF[0], dropoff_lng=DROPOFF[1], dropoff_landmark="Ntinda shopping centre",
            buyer_name="Buyer One", buyer_phone="0701000111", item_description="Phone charger",
            item_value_ugx=50_000, payment_method="cash",
        )
        d.update(o)
        return d

    def create(self, seller, expect=201, headers=None, **o):
        r = self.post("/v1/deliveries", seller, self.payload(**o), headers=headers)
        assert r.status_code == expect, r.json
        return r.json

    def offers(self, boda):
        return self.get("/v1/bodas/me/offers", boda).json["offers"]

    def process(self):
        return worker.run_once(self.ctx)

    def buyer_pin(self, phone="+256701000111"):
        self.process()
        for body in reversed(self.sms.to(phone)):
            m = re.search(r"delivery code is (\d{4})", body)
            if m:
                return m.group(1)
        raise AssertionError("no PIN SMS sent to " + phone)

    def complete(self, seller, boda, minutes=10, **o):
        """Create, accept, pick up and confirm. Returns the delivery id."""
        self.repong()  # earlier steps may have advanced the clock past the location freshness limit
        d = self.create(seller, **o)
        assert self.post("/v1/deliveries/%s/accept" % d["id"], boda).status_code == 200
        assert self.post("/v1/deliveries/%s/pickup" % d["id"], boda).status_code == 200
        self.clock.advance(minutes * 60)
        pin = self.buyer_pin(o.get("buyer_phone_e164", "+256701000111"))
        r = self.post("/v1/deliveries/%s/confirm" % d["id"], boda, {"pin": pin})
        assert r.status_code == 200, r.json
        return d["id"]

    def status(self, delivery_id):
        return self.ctx.db.execute("SELECT status FROM deliveries WHERE id=?", (delivery_id,)).fetchone()[0]

    def buyer_review_token(self, delivery_id):
        self.process()
        for _p, body in reversed(self.sms.messages):
            m = re.search(r"/r/%s\?t=(\S+)" % delivery_id, body)
            if m:
                return m.group(1)
        raise AssertionError("no review link sent")

    def webhook(self, payload, secret=WEBHOOK_SECRET, signature=None):
        raw = json.dumps(payload).encode()
        sig = signature if signature is not None else sign_webhook(secret, raw)
        return self.client.post("/v1/webhooks/payments", data=raw, headers={"X-Signature": sig, "Content-Type": "application/json"})


@pytest.fixture
def make_world(tmp_path):
    def _make(**overrides):
        return World(tmp_path, **overrides)
    return _make


@pytest.fixture
def w(make_world):
    return make_world()
