import json

import pytest

from conftest import DROPOFF, FAR, NEAR1, NEAR2, NEAR3, NEAR4, PICKUP

SECRET_KEYS = ("pin", "hash", "idempotency")


def no_secret_keys(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            assert not any(s in k.lower() for s in SECRET_KEYS), k
            no_secret_keys(v)
    elif isinstance(obj, list):
        for v in obj:
            no_secret_keys(v)


# ------------------------------------------------------------------ pricing and creation

def test_quote_matches_created_delivery(w):
    s = w.seller()
    q = w.post("/v1/quote", s, {"pickup_lat": PICKUP[0], "pickup_lng": PICKUP[1], "dropoff_lat": DROPOFF[0], "dropoff_lng": DROPOFF[1]}).json
    assert q == {"distance_km": 5.3, "fee_ugx": 6500, "eta_minutes": 21}
    d = w.create(s)
    assert (d["distance_km"], d["fee_ugx"], d["eta_minutes"]) == (5.3, 6500, 21)


@pytest.mark.parametrize("change,code", [
    ({"dropoff_lat": PICKUP[0], "dropoff_lng": PICKUP[1]}, "same_location"),
    ({"dropoff_lat": 1.5, "dropoff_lng": 33.5}, "too_far"),
])
def test_unreasonable_trips_rejected(w, change, code):
    s = w.seller()
    r = w.post("/v1/deliveries", s, w.payload(**change))
    assert r.status_code == 422 and r.json["error"]["code"] == code


@pytest.mark.parametrize("change", [
    {"pickup_lat": 123}, {"item_value_ugx": -5}, {"item_value_ugx": 1.5}, {"item_value_ugx": "1000"},
    {"payment_method": "bitcoin"}, {"buyer_phone": "nope"}, {"item_description": ""},
])
def test_invalid_delivery_fields_rejected(w, change):
    s = w.seller()
    assert w.post("/v1/deliveries", s, w.payload(**change)).status_code in (422,)


def test_create_never_exposes_pin_and_texts_the_buyer(w):
    s = w.seller()
    d = w.create(s)
    no_secret_keys(d)
    assert d["status"] == "SEARCHING"
    pin = w.buyer_pin()
    assert len(pin) == 4 and pin.isdigit()
    assert pin not in json.dumps(w.get("/v1/deliveries/" + d["id"], s).json)
    # After sending, the PIN no longer sits in the outbox table.
    bodies = [r[0] for r in w.ctx.db.execute("SELECT body FROM sms_outbox WHERE status='sent'")]
    assert all(pin not in b for b in bodies)


def test_idempotency_key_prevents_double_booking(w):
    s = w.seller()
    h = {"Idempotency-Key": "order-12345678"}
    a = w.post("/v1/deliveries", s, w.payload(), headers=h)
    b = w.post("/v1/deliveries", s, w.payload(), headers=h)
    assert (a.status_code, b.status_code) == (201, 200) and a.json["id"] == b.json["id"]
    assert w.ctx.db.execute("SELECT COUNT(*) FROM deliveries").fetchone()[0] == 1
    assert w.post("/v1/deliveries", s, w.payload(), headers={"Idempotency-Key": "x"}).status_code == 422


def test_open_delivery_limit(make_world):
    w = make_world(max_open_deliveries_per_seller=2)
    s = w.seller()
    w.create(s)
    w.create(s)
    assert w.post("/v1/deliveries", s, w.payload()).status_code == 429


# ------------------------------------------------------------------ matching

def test_nearest_three_get_offers_and_ineligible_riders_do_not(w):
    s = w.seller()
    near = [w.boda(loc, phone=p) for loc, p in ((NEAR3, "0772000003"), (NEAR1, "0772000001"), (NEAR4, "0772000004"), (NEAR2, "0772000002"))]
    far = w.boda(FAR, phone="0772000005")
    offline = w.boda(NEAR1, available=False, phone="0772000006")
    stale = w.boda(NEAR1, phone="0772000007")
    w.clock.advance(w.cfg.location_max_age_seconds + 1)
    for b in near + [far, offline]:
        w.ping(b)  # everyone except `stale` refreshes their location
    w.create(s)
    got = {b.phone for b in near + [far, offline, stale] if w.offers(b)}
    assert got == {"+256772000001", "+256772000002", "+256772000003"}  # nearest three only


def test_item_value_above_trust_cap_is_not_offered(w):
    s, b = w.seller(), w.boda()
    d = w.create(s, item_value_ugx=w.cfg.new_boda_value_cap_ugx + 1)
    assert w.offers(b) == []
    assert w.post("/v1/deliveries/%s/accept" % d["id"], b).status_code == 404


def test_offer_hides_buyer_until_accepted_then_hides_again_when_done(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    offer = w.offers(b)[0]
    assert "buyer_phone" not in offer and "buyer_name" not in offer
    assert offer["earning_ugx"] == 5850 and offer["distance_to_pickup_km"] < 0.2
    no_secret_keys(offer)
    accepted = w.post("/v1/deliveries/%s/accept" % d["id"], b).json
    assert accepted["buyer_phone"] == "+256701000111"
    w.post("/v1/deliveries/%s/pickup" % d["id"], b)
    w.clock.advance(300)
    w.post("/v1/deliveries/%s/confirm" % d["id"], b, {"pin": w.buyer_pin()})
    done = w.get("/v1/deliveries/" + d["id"], b).json
    assert done["status"] == "DELIVERED" and "buyer_phone" not in done


def test_expired_offers_roll_to_next_riders_then_give_up(w):
    s = w.seller()
    first = [w.boda(l, phone=p) for l, p in ((NEAR1, "0772000001"), (NEAR2, "0772000002"), (NEAR3, "0772000003"))]
    fourth = w.boda(NEAR4, phone="0772000004")
    d = w.create(s)
    assert all(w.offers(b) for b in first) and not w.offers(fourth)
    w.clock.advance(w.cfg.offer_ttl_seconds + 1)
    w.repong()
    assert w.process()["dispatched"] == 1
    assert not any(w.offers(b) for b in first)  # expired, and not re-offered
    assert w.offers(fourth)
    # Nobody is left; two more empty rounds and the seller is told.
    for _ in range(3):
        w.clock.advance(w.cfg.offer_ttl_seconds + 1)
        w.repong()
        w.process()
    assert w.status(d["id"]) == "NO_BODA"
    assert any("no rider" in m.lower() for m in w.sms.to(s.phone))


def test_declines_trigger_next_round_immediately(w):
    s = w.seller()
    first = [w.boda(l, phone=p) for l, p in ((NEAR1, "0772000001"), (NEAR2, "0772000002"), (NEAR3, "0772000003"))]
    fourth = w.boda(NEAR4, phone="0772000004")
    d = w.create(s)
    for b in first:
        assert w.post("/v1/deliveries/%s/decline" % d["id"], b).status_code == 200
    assert w.offers(fourth)  # no waiting for the timer


def test_no_riders_at_all_ends_in_no_boda(w):
    s = w.seller()
    d = w.create(s)
    for _ in range(w.cfg.max_dispatch_rounds):
        w.clock.advance(w.cfg.offer_ttl_seconds + 1)
        w.process()
    assert w.status(d["id"]) == "NO_BODA"


# ------------------------------------------------------------------ the happy path and state machine

def test_full_delivery_flow(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    acc = w.post("/v1/deliveries/%s/accept" % d["id"], b)
    assert acc.status_code == 200 and acc.json["status"] == "ASSIGNED"
    seller_view = w.get("/v1/deliveries/" + d["id"], s).json
    assert seller_view["boda"]["plate_number"].startswith("UBA") and seller_view["boda"]["phone"] == b.phone
    w.process()
    assert any(b.phone in m and "accepted" in m for m in w.sms.to(s.phone))   # seller is told who is coming
    assert any("collecting" in m for m in w.sms.to("+256701000111"))          # and so is the buyer
    assert w.post("/v1/deliveries/%s/pickup" % d["id"], b).json["status"] == "PICKED_UP"
    w.clock.advance(600)
    done = w.post("/v1/deliveries/%s/confirm" % d["id"], b, {"pin": w.buyer_pin()})
    assert done.status_code == 200 and done.json["status"] == "DELIVERED"
    assert done.json["payment"]["status"] == "paid"  # cash
    events = [r[0] for r in w.ctx.db.execute("SELECT to_status FROM delivery_events WHERE delivery_id=? ORDER BY id", (d["id"],))]
    assert events == ["SEARCHING", "ASSIGNED", "PICKED_UP", "DELIVERED"]
    assert w.get("/v1/bodas/me/active", b).json["delivery"] is None
    assert len(w.get("/v1/bodas/me/history", b).json["deliveries"]) == 1


def test_state_machine_blocks_skipping_steps(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    assert w.post("/v1/deliveries/%s/pickup" % d["id"], b).status_code == 404       # not theirs yet
    w.post("/v1/deliveries/%s/accept" % d["id"], b)
    assert w.post("/v1/deliveries/%s/confirm" % d["id"], b, {"pin": "0000"}).status_code == 409  # not picked up
    w.post("/v1/deliveries/%s/pickup" % d["id"], b)
    assert w.post("/v1/deliveries/%s/pickup" % d["id"], b).status_code == 409
    assert w.post("/v1/deliveries/%s/accept" % d["id"], b).status_code == 409


def test_second_rider_cannot_take_a_taken_job_and_busy_rider_cannot_double_up(w):
    s = w.seller()
    b1, b2 = w.boda(NEAR1, phone="0772000001"), w.boda(NEAR2, phone="0772000002")
    d1 = w.create(s)
    assert w.post("/v1/deliveries/%s/accept" % d1["id"], b1).status_code == 200
    late = w.post("/v1/deliveries/%s/accept" % d1["id"], b2)
    assert late.status_code == 409 and late.json["error"]["code"] == "no_longer_available"
    assert w.offers(b2) == []  # offer withdrawn
    d2 = w.create(s, buyer_phone="0701000222")
    assert w.offers(b1) == []   # a rider with a job in progress is not offered another
    busy = w.post("/v1/deliveries/%s/accept" % d2["id"], b1)
    assert busy.status_code == 404
    assert w.offers(b2)         # the free rider gets the second job instead


def test_expired_offer_cannot_be_accepted(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    w.clock.advance(w.cfg.offer_ttl_seconds + 1)
    r = w.post("/v1/deliveries/%s/accept" % d["id"], b)
    assert r.status_code == 409 and r.json["error"]["code"] == "no_longer_available"


# ------------------------------------------------------------------ PIN safety

def test_wrong_pins_are_counted_then_locked_and_admin_can_resolve(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    w.post("/v1/deliveries/%s/accept" % d["id"], b)
    w.post("/v1/deliveries/%s/pickup" % d["id"], b)
    real = w.buyer_pin()
    wrong = "0000" if real != "0000" else "1111"
    remaining = []
    for _ in range(w.cfg.pin_max_attempts):
        r = w.post("/v1/deliveries/%s/confirm" % d["id"], b, {"pin": wrong})
        assert r.status_code == 400
        remaining.append(r.json["error"]["details"]["attempts_remaining"])
    assert remaining == [4, 3, 2, 1, 0]
    locked = w.post("/v1/deliveries/%s/confirm" % d["id"], b, {"pin": real})
    assert locked.status_code == 423 and locked.json["error"]["code"] == "pin_locked"  # even the right PIN
    w.process()
    assert any("locked" in m for m in w.sms.to(s.phone))
    r = w.post("/v1/admin/deliveries/%s/resolve" % d["id"], w.admin, {"outcome": "DELIVERED", "note": "buyer confirmed by phone"})
    assert r.status_code == 200 and r.json["status"] == "DELIVERED"


def test_pin_format_is_validated(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    w.post("/v1/deliveries/%s/accept" % d["id"], b)
    w.post("/v1/deliveries/%s/pickup" % d["id"], b)
    for bad in ("12", "12345", "abcd", ""):
        assert w.post("/v1/deliveries/%s/confirm" % d["id"], b, {"pin": bad}).status_code == 422
    assert w.ctx.db.execute("SELECT pin_attempts FROM deliveries").fetchone()[0] == 0


def test_pin_for_one_delivery_does_not_work_on_another(w):
    s = w.seller()
    b1, b2 = w.boda(NEAR1, phone="0772000001"), w.boda(NEAR2, phone="0772000002")
    d1 = w.create(s, buyer_phone="0701000111")
    d2 = w.create(s, buyer_phone="0701000222")
    pin1 = w.buyer_pin("+256701000111")
    w.post("/v1/deliveries/%s/accept" % d1["id"], b1)
    w.post("/v1/deliveries/%s/accept" % d2["id"], b2)
    w.post("/v1/deliveries/%s/pickup" % d2["id"], b2)
    pin2 = w.buyer_pin("+256701000222")
    if pin1 == pin2:  # 1-in-10,000 collision: pick any code that is not delivery 2's
        pin1 = "0000" if pin2 != "0000" else "1111"
    wrong = w.post("/v1/deliveries/%s/confirm" % d2["id"], b2, {"pin": pin1})
    assert wrong.status_code == 400 and wrong.json["error"]["code"] == "wrong_pin"
    assert w.post("/v1/deliveries/%s/confirm" % d2["id"], b2, {"pin": pin2}).status_code == 200


# ------------------------------------------------------------------ cancel and access control

def test_seller_cancel_rules(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    assert w.post("/v1/deliveries/%s/cancel" % d["id"], s, {"reason": "changed my mind"}).json["status"] == "CANCELLED"
    assert w.offers(b) == []
    assert w.post("/v1/deliveries/%s/cancel" % d["id"], s).status_code == 409  # already cancelled
    d2 = w.create(s)
    w.post("/v1/deliveries/%s/accept" % d2["id"], b)
    assert w.post("/v1/deliveries/%s/cancel" % d2["id"], s).status_code == 200  # still allowed before pickup
    w.process()
    assert any("cancelled" in m for m in w.sms.to(b.phone))  # the rider is told not to go
    d3 = w.create(s)
    w.post("/v1/deliveries/%s/accept" % d3["id"], b)
    w.post("/v1/deliveries/%s/pickup" % d3["id"], b)
    late = w.post("/v1/deliveries/%s/cancel" % d3["id"], s)
    assert late.status_code == 409 and late.json["error"]["code"] == "cannot_cancel"


def test_rider_dropping_a_job_sends_it_to_others_but_never_back_to_them(w):
    s = w.seller()
    b1, b2, b3 = (w.boda(l, phone=p) for l, p in ((NEAR1, "0772000001"), (NEAR2, "0772000002"), (NEAR3, "0772000003")))
    d = w.create(s)
    w.post("/v1/deliveries/%s/accept" % d["id"], b1)
    assert w.offers(b2) == []                       # withdrawn when b1 took it
    r = w.post("/v1/deliveries/%s/cancel" % d["id"], b1, {"reason": "bike broke down"})
    assert r.status_code == 200 and r.json["status"] == "SEARCHING"
    assert w.offers(b1) == []                       # not offered the job they dropped
    assert w.offers(b2) and w.offers(b3)            # others get another chance
    assert w.post("/v1/deliveries/%s/accept" % d["id"], b2).status_code == 200


def test_people_only_see_their_own_deliveries(w):
    s1, s2 = w.seller("0701000001"), w.seller("0701000002")
    b, other = w.boda(NEAR1, phone="0772000001"), w.boda(FAR, phone="0772000002")
    d = w.create(s1)
    assert w.get("/v1/deliveries/" + d["id"], s2).status_code == 404
    assert w.get("/v1/deliveries/" + d["id"], other).status_code == 404
    assert w.get("/v1/deliveries/" + d["id"], b).status_code == 200  # has a live offer
    assert w.get("/v1/deliveries/" + d["id"], w.admin).status_code == 200
    assert w.post("/v1/deliveries/%s/cancel" % d["id"], s2).status_code == 404
    assert w.get("/v1/deliveries", s2).json["deliveries"] == []
    assert len(w.get("/v1/deliveries", s1).json["deliveries"]) == 1


def test_admin_resolve_requires_active_delivery(w):
    s = w.seller()
    d = w.create(s)
    r = w.post("/v1/admin/deliveries/%s/resolve" % d["id"], w.admin, {"outcome": "FAILED", "note": "test"})
    assert r.status_code == 409
