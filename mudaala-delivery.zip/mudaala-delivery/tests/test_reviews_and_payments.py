import json
import time

from conftest import NEAR1, NEAR2, NEAR3

GOOD = {"courtesy": 5, "condition_ok": True}


def two_deliveries_done(w, minutes=10):
    s, b = w.seller(), w.boda()
    ids = [w.complete(s, b, minutes, buyer_phone="0701000111")]
    return s, b, ids


# ------------------------------------------------------------------ reviews

def test_time_is_measured_by_the_system_not_typed_in(w):
    s, b = w.seller(), w.boda()
    fast = w.complete(s, b, minutes=10)       # ETA is 21 minutes
    slow = w.complete(s, b, minutes=40)
    r1 = w.post("/v1/deliveries/%s/review" % fast, s, GOOD).json
    r2 = w.post("/v1/deliveries/%s/review" % slow, s, GOOD).json
    assert r1["on_time"] is True and r1["minutes_taken"] == 10.0
    assert r2["on_time"] is False and r2["minutes_taken"] == 40.0
    # A reviewer cannot claim the rider was on time: unknown fields are refused outright.
    fresh = w.complete(s, b, minutes=40)
    cheat = w.post("/v1/deliveries/%s/review" % fresh, s, {**GOOD, "on_time": True})
    assert cheat.status_code == 422 and cheat.json["error"]["code"] == "validation_error"


def test_review_preconditions(w):
    s, b = w.seller(), w.boda()
    pending = w.create(s)
    assert w.post("/v1/deliveries/%s/review" % pending["id"], s, GOOD).status_code == 409   # not delivered
    done = w.complete(s, b)
    assert w.post("/v1/deliveries/%s/review" % done, s, GOOD).status_code == 201
    dup = w.post("/v1/deliveries/%s/review" % done, s, GOOD)
    assert dup.status_code == 409 and dup.json["error"]["code"] == "already_reviewed"
    other = w.seller("0701000002")
    assert w.post("/v1/deliveries/%s/review" % done, other, GOOD).status_code == 404
    assert w.post("/v1/deliveries/%s/review" % done, b, GOOD).status_code == 403          # riders cannot review themselves


def test_damage_requires_a_note_and_ratings_are_bounded(w):
    s, b = w.seller(), w.boda()
    d = w.complete(s, b)
    r = w.post("/v1/deliveries/%s/review" % d, s, {"courtesy": 3, "condition_ok": False})
    assert r.status_code == 422 and r.json["error"]["code"] == "damage_note_required"
    for bad in (0, 6, "5", 4.5):
        assert w.post("/v1/deliveries/%s/review" % d, s, {"courtesy": bad, "condition_ok": True}).status_code == 422
    ok = w.post("/v1/deliveries/%s/review" % d, s, {"courtesy": 2, "condition_ok": False, "damage_note": "screen cracked"})
    assert ok.status_code == 201


def test_review_window_closes(w):
    s, b = w.seller(), w.boda()
    d = w.complete(s, b)
    w.clock.advance(w.cfg.review_window_days * 86400 + 1)
    r = w.post("/v1/deliveries/%s/review" % d, s, GOOD)
    assert r.status_code == 409 and r.json["error"]["code"] == "review_window_closed"


def test_buyer_can_review_only_with_the_secret_link(w):
    s, b = w.seller(), w.boda()
    d = w.complete(s, b)
    url = "/v1/public/deliveries/%s/review" % d
    assert w.post(url, None, {**GOOD, "token": "wrong-token-value"}).status_code == 404
    assert w.post("/v1/public/deliveries/nonexistent/review", None, {**GOOD, "token": "wrong-token-value"}).status_code == 404
    token = w.buyer_review_token(d)
    assert w.post(url, None, {**GOOD, "token": token}).status_code == 201
    assert w.post(url, None, {**GOOD, "token": token}).status_code == 409  # one review per buyer
    # Seller can still leave their own, separately.
    assert w.post("/v1/deliveries/%s/review" % d, s, GOOD).status_code == 201


def test_score_is_hidden_until_enough_reviews_then_shrinks_toward_prior(w):
    s, b = w.seller(), w.boda()
    ids = [w.complete(s, b, 10) for _ in range(3)]
    for i in ids[:2]:
        w.post("/v1/deliveries/%s/review" % i, s, GOOD)
    hidden = w.get("/v1/bodas/" + b.id, s).json["rating"]
    assert hidden["score"] is None and hidden["review_count"] == 2
    w.post("/v1/deliveries/%s/review" % ids[2], s, GOOD)
    r = w.get("/v1/bodas/" + b.id, s).json["rating"]
    # three perfect reviews: (5*4.0 prior + 3*5.0) / (5 + 3) = 4.375, not a flat 5.0
    assert r["score"] == 4.38 and r["review_count"] == 3
    assert r["on_time_rate"] == 1.0 and r["arrived_intact_rate"] == 1.0 and r["avg_courtesy"] == 5.0


def test_bad_reviews_pull_the_score_down(w):
    s, b = w.seller(), w.boda()
    for _ in range(3):
        d = w.complete(s, b, minutes=60)
        w.post("/v1/deliveries/%s/review" % d, s, {"courtesy": 1, "condition_ok": False, "damage_note": "box crushed"})
    r = w.get("/v1/bodas/" + b.id, s).json["rating"]
    assert r["score"] < 3 and r["on_time_rate"] == 0.0 and r["arrived_intact_rate"] == 0.0


def test_rider_can_reply_once_and_only_to_their_own_reviews(w):
    s = w.seller()
    b1, b2 = w.boda(NEAR1, phone="0772000001"), w.boda(NEAR2, phone="0772000002")
    d = w.complete(s, b1)
    w.post("/v1/deliveries/%s/review" % d, s, {"courtesy": 2, "condition_ok": False, "damage_note": "dented"})
    rid = w.get("/v1/bodas/%s/reviews" % b1.id, s).json["reviews"][0]["id"]
    assert w.post("/v1/reviews/%s/reply" % rid, b2, {"text": "not mine"}).status_code == 404
    assert w.post("/v1/reviews/%s/reply" % rid, b1, {"text": "Road was flooded, sorry."}).status_code == 200
    assert w.post("/v1/reviews/%s/reply" % rid, b1, {"text": "again"}).status_code == 409
    shown = w.get("/v1/bodas/%s/reviews" % b1.id, s).json["reviews"][0]
    assert shown["boda_reply"] == "Road was flooded, sorry." and shown["damage_note"] == "dented"
    assert "delivery_id" not in shown  # reviewers are not identifiable from the public list


def test_reviews_of_unapproved_riders_are_not_listed(w):
    s = w.seller()
    b = w.boda(approve=False)
    assert w.get("/v1/bodas/%s/reviews" % b.id, s).status_code == 404


# ------------------------------------------------------------------ payments

def test_cash_delivery_is_recorded_and_earnings_add_up(w):
    s, b = w.seller(), w.boda()
    w.complete(s, b)
    w.complete(s, b)
    e = w.get("/v1/bodas/me/earnings", b).json
    assert e == {"paid_deliveries": 2, "total_fees_ugx": 13000, "total_commission_ugx": 1300, "total_earnings_ugx": 11700}
    assert not w.provider.charges  # cash never touches the provider


def test_mobile_money_is_charged_once_and_settled_by_signed_webhook(w):
    s, b = w.seller(), w.boda()
    d = w.complete(s, b, payment_method="mobile_money")
    assert len(w.provider.charges) == 1
    pid, phone, amount = w.provider.charges[0]
    assert (phone, amount) == (s.phone, 6500)
    row = w.ctx.db.execute("SELECT status, provider_ref FROM payments WHERE id=?", (pid,)).fetchone()
    assert (row["status"], row["provider_ref"]) == ("processing", "ref-" + pid)
    w.process()
    assert len(w.provider.charges) == 1  # the worker does not charge again

    evt = {"event_id": "evt-1", "provider_ref": "ref-" + pid, "status": "paid"}
    assert w.webhook(evt).json == {"status": "applied"}
    assert w.webhook(evt).json == {"status": "duplicate"}       # provider retries are harmless
    assert w.get("/v1/deliveries/" + d, s).json["payment"]["status"] == "paid"
    assert w.get("/v1/bodas/me/earnings", b).json["paid_deliveries"] == 1


def test_webhook_rejects_forgeries(w):
    s, b = w.seller(), w.boda()
    w.complete(s, b, payment_method="mobile_money")
    ref = "ref-" + w.provider.charges[0][0]
    evt = {"event_id": "evt-9", "provider_ref": ref, "status": "paid"}
    assert w.webhook(evt, secret="x" * 32).status_code == 401
    assert w.webhook(evt, signature="").status_code == 401
    raw = b"not json"
    from mudaala_delivery.security import sign_webhook
    r = w.client.post("/v1/webhooks/payments", data=raw, headers={"X-Signature": sign_webhook(w.cfg.webhook_secret, raw)})
    assert r.status_code == 400
    assert w.webhook({"event_id": "e", "provider_ref": ref, "status": "refunded"}).status_code == 400
    assert w.ctx.db.execute("SELECT status FROM payments").fetchone()[0] == "processing"  # nothing slipped through
    assert w.webhook({"event_id": "e2", "provider_ref": "unknown", "status": "paid"}).json == {"status": "ignored"}


def test_failed_charge_never_blocks_delivery_and_is_retried(w):
    s, b = w.seller(), w.boda()
    w.provider.fail = True
    d = w.complete(s, b, payment_method="mobile_money")
    assert w.status(d) == "DELIVERED"
    assert w.ctx.db.execute("SELECT status, attempts FROM payments").fetchone()[:] == ("pending", 1)
    w.provider.fail = False
    w.process()
    assert len(w.provider.charges) == 1
    assert w.ctx.db.execute("SELECT status FROM payments").fetchone()[0] == "processing"


def test_charge_gives_up_after_repeated_failures(w):
    s, b = w.seller(), w.boda()
    w.provider.fail = True
    w.complete(s, b, payment_method="mobile_money")
    for _ in range(10):
        w.process()
    row = w.ctx.db.execute("SELECT status, attempts FROM payments").fetchone()
    assert row["status"] == "failed" and row["attempts"] == 5


def test_charge_interrupted_by_a_crash_is_picked_up_later(w):
    s, b = w.seller(), w.boda()
    w.provider.fail = True
    w.complete(s, b, payment_method="mobile_money")
    w.provider.fail = False
    now = w.ctx.now()
    # Simulate a worker that claimed the payment and died before calling the provider.
    w.ctx.db.execute("UPDATE payments SET status='processing', provider_ref=NULL, updated_at=?", (now,))
    w.process()
    assert not w.provider.charges                     # too soon: might still be in flight
    w.clock.advance(301)
    w.process()
    assert len(w.provider.charges) == 1


def test_sms_failures_are_retried_then_marked_failed(w):
    s = w.seller()
    w.sms.fail = True
    w.create(s)
    for _ in range(6):
        w.process()
    assert w.ctx.db.execute("SELECT status FROM sms_outbox").fetchone()[0] == "failed"
    w.sms.fail = False
    d2 = w.create(s)
    w.process()
    assert w.ctx.db.execute("SELECT COUNT(*) FROM sms_outbox WHERE status='sent'").fetchone()[0] >= 1
