"""Real threads against a real SQLite file: the races these tests guard against are the ones
that cost money in production (double assignment, double booking, PIN brute force)."""

import threading
import time

import pytest

from mudaala_delivery import security
from mudaala_delivery.errors import ApiError
from mudaala_delivery.services import bodas, deliveries

from conftest import NEAR1, NEAR2, NEAR3


@pytest.fixture(autouse=True)
def widen_race_window(monkeypatch):
    """Without this the threads finish so quickly that they rarely overlap, and the tests would
    pass even if the locking were removed. A short pause between each transaction's reads and
    its writes forces the overlap, so these tests fail if the database stops serialising writers."""
    real_count, real_hash = bodas.completed_count, security.hash_pin

    def slow_count(*a, **k):
        time.sleep(0.04)
        return real_count(*a, **k)

    def slow_hash(*a, **k):
        time.sleep(0.04)
        return real_hash(*a, **k)

    monkeypatch.setattr(bodas, "completed_count", slow_count)
    monkeypatch.setattr(security, "hash_pin", slow_hash)


def run_threads(n, fn):
    barrier, results = threading.Barrier(n), [None] * n

    def target(i):
        barrier.wait()
        try:
            results[i] = ("ok", fn(i))
        except ApiError as e:
            results[i] = ("err", e.code)
        except Exception as e:  # any other failure is a real bug
            results[i] = ("crash", repr(e))

    threads = [threading.Thread(target=target, args=(i,)) for i in range(n)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    return results


def test_only_one_rider_wins_a_job_that_many_accept_at_once(w):
    s = w.seller()
    riders = [w.boda(l, phone=p) for l, p in ((NEAR1, "0772000001"), (NEAR2, "0772000002"), (NEAR3, "0772000003"))]
    d = w.create(s)
    users = [dict(id=b.id, name="x", phone=b.phone, role="boda") for b in riders]
    results = run_threads(3, lambda i: deliveries.accept(w.ctx, users[i], d["id"]))
    assert not [r for r in results if r[0] == "crash"], results
    assert sorted(r[0] for r in results) == ["err", "err", "ok"]
    assert {r[1] for r in results if r[0] == "err"} == {"no_longer_available"}
    row = w.ctx.db.execute("SELECT status, boda_id FROM deliveries").fetchone()
    assert row["status"] == "ASSIGNED" and row["boda_id"] in {b.id for b in riders}


def test_one_rider_cannot_win_two_jobs_at_once(w):
    s = w.seller()
    b = w.boda()
    d1, d2 = w.create(s, buyer_phone="0701000111"), w.create(s, buyer_phone="0701000222")
    u = dict(id=b.id, name="x", phone=b.phone, role="boda")
    results = run_threads(2, lambda i: deliveries.accept(w.ctx, u, (d1, d2)[i]["id"]))
    assert not [r for r in results if r[0] == "crash"], results
    assert sorted(r[0] for r in results) == ["err", "ok"]
    assert w.ctx.db.execute("SELECT COUNT(*) FROM deliveries WHERE status='ASSIGNED'").fetchone()[0] == 1


def test_same_idempotency_key_sent_in_parallel_creates_one_delivery(w):
    s = w.seller()
    user = dict(id=s.id, name="Seller", phone=s.phone, role="seller")
    results = run_threads(8, lambda i: deliveries.create(w.ctx, user, w.payload(), "same-key-12345"))
    assert not [r for r in results if r[0] == "crash"], results
    assert sum(1 for r in results if r[1][1] is True) == 1  # exactly one real creation
    assert len({r[1][0]["id"] for r in results}) == 1
    assert w.ctx.db.execute("SELECT COUNT(*) FROM deliveries").fetchone()[0] == 1


def test_parallel_pin_guessing_cannot_exceed_the_attempt_limit(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    w.post("/v1/deliveries/%s/accept" % d["id"], b)
    w.post("/v1/deliveries/%s/pickup" % d["id"], b)
    real = w.buyer_pin()
    wrong = [("%04d" % n) for n in range(30) if ("%04d" % n) != real][:20]
    u = dict(id=b.id, name="x", phone=b.phone, role="boda")
    results = run_threads(20, lambda i: deliveries.confirm(w.ctx, u, d["id"], wrong[i]))
    assert not [r for r in results if r[0] == "crash"], results
    codes = sorted(r[1] for r in results)
    assert codes.count("wrong_pin") == w.cfg.pin_max_attempts
    assert codes.count("pin_locked") == 20 - w.cfg.pin_max_attempts
    assert w.ctx.db.execute("SELECT pin_attempts, status FROM deliveries").fetchone()[:] == (5, "PICKED_UP")


def test_seller_cancel_racing_rider_accept_ends_in_one_consistent_state(w):
    s, b = w.seller(), w.boda()
    d = w.create(s)
    seller_u = dict(id=s.id, name="S", phone=s.phone, role="seller")
    boda_u = dict(id=b.id, name="B", phone=b.phone, role="boda")
    def act(i):
        return deliveries.cancel(w.ctx, seller_u, d["id"]) if i == 0 else deliveries.accept(w.ctx, boda_u, d["id"])
    results = run_threads(2, act)
    assert not [r for r in results if r[0] == "crash"], results
    status = w.status(d["id"])
    assert status in ("CANCELLED", "ASSIGNED")
    if status == "ASSIGNED":
        assert w.ctx.db.execute("SELECT boda_id FROM deliveries").fetchone()[0] == b.id
